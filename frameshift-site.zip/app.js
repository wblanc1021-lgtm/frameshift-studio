(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
  const formatTime = seconds => {
    const safe = Number.isFinite(seconds) ? Math.max(0, seconds) : 0;
    const m = Math.floor(safe / 60);
    const s = Math.floor(safe % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };
  const ratioLabel = (width, height) => {
    if (!width || !height) return state?.aspect || '16:9';
    const ratio = width / height;
    if (ratio > 1.35) return '16:9';
    if (ratio < .8) return '9:16';
    return '1:1';
  };

  const performances = [
    { id: 'black', name: 'Black coat', style: 'Cinematic', camera: 'Drift', art: 'sample-black', image: './assets/performance/black-coat.jpg', prompt: 'She walks two steps toward the camera, stops, and looks back over her shoulder. Wet night street, one blue neon sign, long black coat.' },
    { id: 'red', name: 'Red coat', style: 'Illustrated', camera: 'Hold', art: 'sample-red', image: './assets/performance/red-coat.jpg', prompt: 'The drawn figure turns their head, then takes one step. Ink line, flat red coat, cream paper, no extra people.' },
    { id: 'ivory', name: 'Ivory suit', style: 'Editorial', camera: 'Push in', art: 'sample-ivory', image: './assets/performance/ivory-suit.jpg', prompt: 'They lift their chin and turn slowly to the left. Seamless white studio, hard light, structured ivory suit.' },
    { id: 'cobalt', name: 'Cobalt glass', style: 'Dusk editorial', camera: 'Push in', art: 'sample-cobalt', image: './assets/performance/cobalt-glass.jpg', prompt: 'They cross the glass corridor, slow at the band of evening light, and turn toward the reflection. Petrol-blue knit, wet concrete, quiet dusk.' }
  ];
  const cameras = {
    'Hold': 'The camera stays locked off, almost still.',
    'Push in': 'A slow, steady dolly push toward the subject.',
    'Orbit': 'A gentle orbit around the subject, smooth and unhurried.',
    'Drift': 'Subtle handheld drift, natural and quiet.',
    'Rise': 'A slow crane rise, revealing a little more of the scene.',
    'Rack': 'A slow rack of focus from the subject into the background.'
  };
  const defaults = {
    schemaVersion: 5,
    mode: 'recast', prompt: performances[0].prompt, spokenLine: '', camera: 'Drift', length: 6,
    aspect: '16:9', presentation: 'keep', lockSubject: true, lockSetting: true, sound: true, sampleId: 'black',
    hintDismissed: false, notificationsEnabled: false, library: [], promptHistory: [],
    quality: 'high', resolution: '1080p', variants: 1, seed: 483201, protectBackground: true,
    identityFidelity: 92, lightingFidelity: 76, motionFidelity: 84, edgeFidelity: 88, temporalFidelity: 90,
    audioMode: 'original', lipSync: 82, originalMix: 72, voiceMix: 88, ambientMix: 42,
    remakeUrl: '', remakePresentation: 'keep', remakeContinuity: 92, remakeDuration: '01:00', remakeTransition: 'seamless',
    remakeKeepMotion: true, remakeKeepCuts: true, remakeKeepAudio: true, remakeKeepSetting: true
  };
  const persistKeys = Object.keys(defaults);
  let restored = {};
  try { restored = JSON.parse(localStorage.getItem('frameshift-state') || '{}'); } catch (_) {}
  const state = { ...defaults, ...(restored && typeof restored === 'object' ? restored : {}) };
  state.schemaVersion = 5;
  if (!['recast', 'animate', 'prompt'].includes(state.mode)) state.mode = 'recast';
  if (typeof state.prompt !== 'string') state.prompt = defaults.prompt;
  state.prompt = state.prompt.slice(0, 800);
  if (typeof state.spokenLine !== 'string') state.spokenLine = '';
  state.spokenLine = state.spokenLine.slice(0, 240);
  if (![4, 6, 8, 10, 15].includes(Number(state.length))) state.length = 6; else state.length = Number(state.length);
  if (!['16:9', '9:16', '1:1'].includes(state.aspect)) state.aspect = '16:9';
  if (!['keep', 'feminine', 'masculine', 'neutral'].includes(state.presentation)) state.presentation = 'keep';
  if (!Object.hasOwn(cameras, state.camera)) state.camera = 'Drift';
  ['lockSubject', 'lockSetting', 'sound', 'hintDismissed', 'protectBackground', 'notificationsEnabled'].forEach(key => { if (typeof state[key] !== 'boolean') state[key] = defaults[key]; });
  if (!['draft', 'standard', 'high', 'master'].includes(state.quality)) state.quality = defaults.quality;
  if (!['720p', '1080p', '4K'].includes(state.resolution)) state.resolution = defaults.resolution;
  if (![1, 2, 4].includes(Number(state.variants))) state.variants = 1; else state.variants = Number(state.variants);
  state.seed = clamp(Math.round(Number(state.seed)) || defaults.seed, 1, 999999999);
  ['identityFidelity', 'lightingFidelity', 'motionFidelity', 'edgeFidelity', 'temporalFidelity', 'lipSync', 'originalMix', 'voiceMix', 'ambientMix'].forEach(key => {
    const value = Math.round(Number(state[key]));
    state[key] = clamp(Number.isFinite(value) ? value : defaults[key], 0, 100);
  });
  if (!['original', 'replace', 'hybrid', 'narration'].includes(state.audioMode)) state.audioMode = defaults.audioMode;
  if (typeof state.remakeUrl !== 'string') state.remakeUrl = '';
  state.remakeUrl = state.remakeUrl.slice(0, 1200);
  if (!['keep', 'feminine', 'masculine', 'neutral'].includes(state.remakePresentation)) state.remakePresentation = 'keep';
  state.remakeContinuity = clamp(Math.round(Number(state.remakeContinuity)) || defaults.remakeContinuity, 50, 100);
  if (!/^\d{1,2}:\d{2}$/.test(state.remakeDuration || '')) state.remakeDuration = defaults.remakeDuration;
  if (!['seamless', 'match', 'morph', 'hard'].includes(state.remakeTransition)) state.remakeTransition = defaults.remakeTransition;
  ['remakeKeepMotion', 'remakeKeepCuts', 'remakeKeepAudio', 'remakeKeepSetting'].forEach(key => { if (typeof state[key] !== 'boolean') state[key] = defaults[key]; });
  if (typeof state.sampleId !== 'string') state.sampleId = 'black';
  if (state.sampleId && !performances.some(p => p.id === state.sampleId)) state.sampleId = 'black';
  if (!Array.isArray(state.library)) state.library = [];
  state.library = state.library.filter(t => t && typeof t === 'object' && typeof t.id === 'string' && typeof t.mode === 'string').slice(0, 16);
  state.library.forEach(take => { take.favorite = !!take.favorite; });
  if (!Array.isArray(state.promptHistory)) state.promptHistory = [];
  state.promptHistory = state.promptHistory.filter(item => item && typeof item.id === 'string' && typeof item.prompt === 'string').slice(0, 12);

  let personMedia = [];
  let startFrame = null;
  let endFrame = null;
  let copiedVideo = null;
  let customPerformance = null;
  let voiceBlob = null;
  let voiceUrl = null;
  let mediaRecorder = null;
  let recordTimer = null;
  let recordingStarted = 0;
  let activeJob = null;
  let stageTakeId = null;
  let previewStream = null;
  let cameraStarting = false;
  let facingMode = 'user';
  let micEnabled = false;
  let fpsFrames = [];
  let deferredInstall = null;
  let libraryFilter = 'all';
  let libraryQuery = '';
  let relinkTakeId = null;
  let remakeSource = null;
  let remakeCharacter = null;
  let remakePlan = null;
  let remakeTransitionFrame = null;
  const liveUrls = new Map();

  const els = {
    sideNav: $('#sideNav'), scrim: $('#scrim'), menuTrigger: $('#menuTrigger'),
    brandMode: $('#brandMode'), startHeading: $('#startHeading'), startEyebrow: $('#startEyebrow'),
    recastSource: $('#recastSource'), animateSource: $('#animateSource'), promptSource: $('#promptSource'),
    performanceList: $('#performanceList'), performanceInput: $('#performanceInput'), performanceUpload: $('#performanceUpload'), customPerformance: $('#customPerformance'), personInput: $('#personInput'), personUpload: $('#personUpload'), personStrip: $('#personStrip'), castCount: $('#castCount'), presentationGroup: $('#presentationGroup'),
    startInput: $('#startInput'), startUpload: $('#startUpload'), startPreview: $('#startPreview'), endInput: $('#endInput'), endUpload: $('#endUpload'), endFileChip: $('#endFileChip'), draftStill: $('#draftStill'),
    copyInput: $('#copyInput'), copyUpload: $('#copyUpload'), copiedFile: $('#copiedFile'),
    stage: $('#stage'), stageArt: $('#stageArt'), stageImage: $('#stageImage'), stageVideo: $('#stageVideo'), holdImage: $('#holdImage'), compareHandle: $('#compareHandle'), compareRange: $('#compareRange'), stageMessage: $('#stageMessage'), stageBusy: $('#stageBusy'), busyTitle: $('#busyTitle'), busyCopy: $('#busyCopy'), stageLabel: $('#stageLabel'), stageStatus: $('#stageStatus'), stageTimecode: $('#stageTimecode'), stageSourceMeta: $('#stageSourceMeta'), stageCaption: $('#stageCaption'), stageDimensions: $('#stageDimensions'), stageCameraMeta: $('#stageCameraMeta'), stageActions: $('#stageActions'), filmstrip: $('#filmstrip'),
    lengthGroup: $('#lengthGroup'), lengthNote: $('#lengthNote'), aspectGroup: $('#aspectGroup'), aspectNote: $('#aspectNote'), cameraGroup: $('#cameraGroup'), cameraCopy: $('#cameraCopy'),
    lockSubject: $('#lockSubject'), lockSetting: $('#lockSetting'), readoutLength: $('#readoutLength'), readoutCamera: $('#readoutCamera'), readoutSound: $('#readoutSound'), qualityGroup: $('#qualityGroup'), resolutionGroup: $('#resolutionGroup'), variantGroup: $('#variantGroup'), fidelitySummary: $('#fidelitySummary'), qualityMark: $('#qualityMark'), protectBackground: $('#protectBackground'), seedInput: $('#seedInput'), randomizeSeed: $('#randomizeSeed'), identityFidelity: $('#identityFidelity'), identityValue: $('#identityValue'), lightingFidelity: $('#lightingFidelity'), lightingValue: $('#lightingValue'), motionFidelity: $('#motionFidelity'), motionValue: $('#motionValue'), edgeFidelity: $('#edgeFidelity'), edgeValue: $('#edgeValue'), temporalFidelity: $('#temporalFidelity'), temporalValue: $('#temporalValue'),
    recordVoice: $('#recordVoice'), voiceInput: $('#voiceInput'), voiceUpload: $('#voiceUpload'), voicePreview: $('#voicePreview'), voiceAudio: $('#voiceAudio'), clearVoice: $('#clearVoice'), voiceTimer: $('#voiceTimer'), spokenLine: $('#spokenLine'), spokenCount: $('#spokenCount'), audioModeGroup: $('#audioModeGroup'), deliveryTags: $('#deliveryTags'), lipSync: $('#lipSync'), lipSyncValue: $('#lipSyncValue'), auditionVoice: $('#auditionVoice'), originalMix: $('#originalMix'), originalMixValue: $('#originalMixValue'), voiceMix: $('#voiceMix'), voiceMixValue: $('#voiceMixValue'), ambientMix: $('#ambientMix'), ambientMixValue: $('#ambientMixValue'), mixSummary: $('#mixSummary'), soundToggle: $('#soundToggle'), soundState: $('#soundState'),
    firstHint: $('#firstHint'), hintText: $('#hintText'), dismissHint: $('#dismissHint'), motionPrompt: $('#motionPrompt'), promptSuggestions: $('#promptSuggestions'), promptCount: $('#promptCount'), savePrompt: $('#savePrompt'), openPromptHistory: $('#openPromptHistory'), promptHistoryCount: $('#promptHistoryCount'), promptHistoryDialog: $('#promptHistoryDialog'), closePromptHistory: $('#closePromptHistory'), promptHistoryList: $('#promptHistoryList'), promptHistoryEmpty: $('#promptHistoryEmpty'), generateButton: $('#generateButton'), generateLabel: $('#generateLabel'), generateLength: $('#generateLength'), generateQuality: $('#generateQuality'), readinessCopy: $('#readinessCopy'),
    libraryCount: $('#libraryCount'), libraryGrid: $('#libraryGrid'), libraryEmpty: $('#libraryEmpty'), libraryStat: $('#libraryStat'), libraryToolbar: $('#libraryToolbar'), librarySearch: $('#librarySearch'), relinkInput: $('#relinkInput'),
    systemStatus: $('#systemStatus'), statusLabel: $('#statusLabel'), statusCopy: $('#statusCopy'),
    appSheet: $('#appSheet'), closeApps: $('#closeApps'), installWeb: $('#installWeb'), installCopy: $('#installCopy'), notificationOption: $('#notificationOption'), notificationCopy: $('#notificationCopy'), notificationState: $('#notificationState'),
    cameraVideo: $('#cameraVideo'), cameraOff: $('#cameraOff'), fpsReadout: $('#fpsReadout'), cameraFacing: $('#cameraFacing'), toggleCamera: $('#toggleCamera'), toggleMic: $('#toggleMic'), flipCamera: $('#flipCamera'), deviceNote: $('#deviceNote'),
    remakeStatus: $('#remakeStatus'), remakeUrl: $('#remakeUrl'), analyzeRemakeUrl: $('#analyzeRemakeUrl'), remakeVideoInput: $('#remakeVideoInput'), remakeVideoUpload: $('#remakeVideoUpload'), remakeMonitor: $('#remakeMonitor'), remakeSourcePlaceholder: $('#remakeSourcePlaceholder'), remakeSourcePoster: $('#remakeSourcePoster'), remakeSourceVideo: $('#remakeSourceVideo'), remakeSourceEmbed: $('#remakeSourceEmbed'), remakeCharacterOverlay: $('#remakeCharacterOverlay'), remakeWipe: $('#remakeWipe'), remakeSourceType: $('#remakeSourceType'), remakeSourceRuntime: $('#remakeSourceRuntime'), remakeSourceName: $('#remakeSourceName'), remakeBlendReadout: $('#remakeBlendReadout'), previewRemakeTransition: $('#previewRemakeTransition'), remakeBlend: $('#remakeBlend'), remakeCharacterInput: $('#remakeCharacterInput'), remakeCharacterUpload: $('#remakeCharacterUpload'), remakeCharacterPreview: $('#remakeCharacterPreview'), remakeCharacterName: $('#remakeCharacterName'), useStudioCast: $('#useStudioCast'), remakePresentationGroup: $('#remakePresentationGroup'), remakeContinuity: $('#remakeContinuity'), remakeContinuityValue: $('#remakeContinuityValue'), remakeDuration: $('#remakeDuration'), remakeTransition: $('#remakeTransition'), remakeTimeline: $('#remakeTimeline'), remakeTimelineEmpty: $('#remakeTimelineEmpty'), remakeSegmentCount: $('#remakeSegmentCount'), remakeSummary: $('#remakeSummary'), exportRemakePlan: $('#exportRemakePlan'), buildRemakePlan: $('#buildRemakePlan'), renderFullRemake: $('#renderFullRemake'), remakeEngineNote: $('#remakeEngineNote'),
    toastRegion: $('#toastRegion')
  };

  let persistTimer = null;
  let storageWarningShown = false;
  function writeState() {
    const payload = {};
    persistKeys.forEach(key => payload[key] = state[key]);
    try { localStorage.setItem('frameshift-state', JSON.stringify(payload)); }
    catch (_) { if (!storageWarningShown) { storageWarningShown = true; toast('Browser storage is full. Remove a take before saving more changes.', 'error'); } }
  }
  function persist(immediate = false) {
    clearTimeout(persistTimer);
    if (immediate) writeState();
    else persistTimer = setTimeout(writeState, 140);
  }

  function toast(message, type = '') {
    const node = document.createElement('div');
    node.className = `toast ${type}`.trim();
    node.textContent = message;
    els.toastRegion.append(node);
    setTimeout(() => { node.classList.add('out'); setTimeout(() => node.remove(), 250); }, 4200);
  }

  function setButtonState(button, selected) {
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  }

  function renderPerformances() {
    if (!els.performanceList.children.length) {
      els.performanceList.innerHTML = performances.map(p => `
        <button class="performance-card" data-performance="${p.id}" aria-pressed="false">
          <span class="perf-thumb"><img src="${p.image}" alt="" loading="eager"></span>
          <span><strong>${p.name}</strong><small>${p.style} · ${p.camera}</small></span>
          <span class="perf-check"><svg><use href="#i-check"/></svg></span>
        </button>`).join('');
      $$('[data-performance]').forEach(button => button.addEventListener('click', () => selectPerformance(button.dataset.performance)));
    }
    $$('[data-performance]').forEach(button => {
      const selected = state.sampleId === button.dataset.performance && !customPerformance;
      button.classList.toggle('selected', selected);
      button.classList.toggle('google-rainbow', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
  }

  function selectPerformance(id, updatePrompt = true) {
    const performance = performances.find(p => p.id === id);
    if (!performance) return;
    if (customPerformance?.ownedUrl) URL.revokeObjectURL(customPerformance.url);
    customPerformance = null;
    state.sampleId = id;
    if (updatePrompt) state.prompt = performance.prompt;
    state.camera = performance.camera;
    stageTakeId = null;
    renderPerformances();
    renderCustomPerformance();
    renderCamera();
    renderComposer();
    renderStage();
    persist();
  }

  function renderCustomPerformance() {
    els.customPerformance.hidden = !customPerformance;
    if (!customPerformance) { els.customPerformance.innerHTML = ''; return; }
    els.customPerformance.innerHTML = `<img src="${customPerformance.url}" alt="Custom performance first frame"><span><strong>${escapeHtml(customPerformance.name)}</strong><small>CUSTOM · ${formatTime(customPerformance.duration)}</small></span><button aria-label="Clear custom performance"><svg><use href="#i-close"/></svg></button>`;
    $('button', els.customPerformance).addEventListener('click', () => {
      if (customPerformance?.ownedUrl) URL.revokeObjectURL(customPerformance.url);
      customPerformance = null;
      state.sampleId = '';
      renderCustomPerformance(); renderPerformances(); renderStage(); renderComposer(); persist();
    });
  }

  async function handlePerformanceFile(file) {
    const extOk = /\.(mp4|webm|mov|mkv|m4v)$/i.test(file?.name || '');
    if (!file || file.size === 0) { toast('That performance file is empty.', 'error'); return; }
    if (!(file.type.startsWith('video/') || extOk)) { toast('Upload a video performance.', 'error'); return; }
    if (file.size > 250 * 1024 * 1024) { toast('Keep a performance under 250 MB.', 'error'); return; }
    let meta;
    try { meta = await inspectVideo(file); } catch (_) { toast('That file has no picture.', 'error'); return; }
    if (!meta.width || !meta.height || !meta.duration) { toast('That file has no picture.', 'error'); return; }
    if (meta.duration > 900.1) { toast('A performance can be up to 15 minutes.', 'error'); return; }
    const frames = await extractVideoFrames(file, [0.02], 960).catch(() => []);
    if (!frames.length) { toast('The opening frame could not be read.', 'error'); return; }
    if (customPerformance?.ownedUrl) URL.revokeObjectURL(customPerformance.url);
    customPerformance = { name:file.name, duration:meta.duration, width:meta.width, height:meta.height, aspect:`${meta.width}:${meta.height}`, url:URL.createObjectURL(frames[0]), ownedUrl:true };
    state.sampleId = '';
    stageTakeId = null;
    renderCustomPerformance(); renderPerformances(); renderStage(); renderComposer(); persist();
    toast('The custom performance is ready.', 'ok');
  }

  function renderOptions() {
    if (!els.lengthGroup.children.length) {
      els.lengthGroup.innerHTML = [4,6,8,10,15].map(n => `<button data-length="${n}" aria-pressed="false">${n}s</button>`).join('');
      $$('[data-length]').forEach(b => b.addEventListener('click', () => { state.length = Number(b.dataset.length); renderOptions(); renderComposer(); persist(); }));
    }
    $$('[data-length]').forEach(b => { const selected = state.length === Number(b.dataset.length); b.classList.toggle('selected', selected); b.setAttribute('aria-pressed', String(selected)); });
    els.lengthNote.hidden = state.length !== 15;
    if (!els.aspectGroup.children.length) {
      els.aspectGroup.innerHTML = ['16:9','9:16','1:1'].map(value => `<button data-aspect="${value}" aria-pressed="false">${value}</button>`).join('');
      $$('[data-aspect]').forEach(b => b.addEventListener('click', () => { state.aspect = b.dataset.aspect; renderOptions(); renderStageMeta(); persist(); }));
    }
    $$('[data-aspect]').forEach(b => { const selected = state.aspect === b.dataset.aspect; b.classList.toggle('selected', selected); b.setAttribute('aria-pressed', String(selected)); });
    if (!els.cameraGroup.children.length) {
      els.cameraGroup.innerHTML = Object.keys(cameras).map(value => `<button data-camera="${value}" aria-pressed="false">${value}</button>`).join('');
      $$('[data-camera]').forEach(b => b.addEventListener('click', () => { state.camera = b.dataset.camera; renderCamera(); renderShotReadout(); renderComposer(); persist(); }));
    }
    if (!els.presentationGroup.children.length) {
      const labels = { keep: 'Keep', feminine: 'Feminine', masculine: 'Masculine', neutral: 'Neutral' };
      els.presentationGroup.innerHTML = Object.entries(labels).map(([value,label]) => `<button data-presentation="${value}" aria-pressed="false">${label}</button>`).join('');
      $$('[data-presentation]').forEach(b => b.addEventListener('click', () => { state.presentation = b.dataset.presentation; renderOptions(); persist(); }));
    }
    $$('[data-presentation]').forEach(b => { const selected = state.presentation === b.dataset.presentation; b.classList.toggle('selected', selected); b.setAttribute('aria-pressed', String(selected)); });
    renderCamera();
    setButtonState(els.lockSubject, state.lockSubject);
    setButtonState(els.lockSetting, state.lockSetting);
    renderShotReadout();
  }

  function renderAdvanced() {
    const qualityLabels = { draft:'Draft', standard:'Standard', high:'High', master:'Master' };
    if (!els.qualityGroup.children.length) {
      els.qualityGroup.innerHTML = Object.entries(qualityLabels).map(([value,label]) => `<button data-quality="${value}" aria-pressed="false">${label}</button>`).join('');
      $$('[data-quality]', els.qualityGroup).forEach(button => button.addEventListener('click', () => { state.quality = button.dataset.quality; renderAdvanced(); persist(); }));
    }
    if (!els.resolutionGroup.children.length) {
      els.resolutionGroup.innerHTML = ['720p','1080p','4K'].map(value => `<button data-resolution="${value}" aria-pressed="false">${value}</button>`).join('');
      $$('[data-resolution]', els.resolutionGroup).forEach(button => button.addEventListener('click', () => { state.resolution = button.dataset.resolution; renderAdvanced(); persist(); }));
    }
    if (!els.variantGroup.children.length) {
      els.variantGroup.innerHTML = [1,2,4].map(value => `<button data-variants="${value}" aria-pressed="false">${value} ${value === 1 ? 'take' : 'takes'}</button>`).join('');
      $$('[data-variants]', els.variantGroup).forEach(button => button.addEventListener('click', () => { state.variants = Number(button.dataset.variants); renderAdvanced(); persist(); }));
    }
    if (!els.audioModeGroup.children.length) {
      const audioLabels = { original:'Original', replace:'Replace', hybrid:'Hybrid', narration:'Narrate' };
      els.audioModeGroup.innerHTML = Object.entries(audioLabels).map(([value,label]) => `<button data-audio-mode="${value}" aria-pressed="false">${label}</button>`).join('');
      $$('[data-audio-mode]', els.audioModeGroup).forEach(button => button.addEventListener('click', () => { state.audioMode = button.dataset.audioMode; state.sound = true; renderAdvanced(); renderVoice(); persist(); }));
    }
    $$('[data-quality]', els.qualityGroup).forEach(button => setButtonState(button, button.dataset.quality === state.quality));
    $$('[data-resolution]', els.resolutionGroup).forEach(button => setButtonState(button, button.dataset.resolution === state.resolution));
    $$('[data-variants]', els.variantGroup).forEach(button => setButtonState(button, Number(button.dataset.variants) === state.variants));
    $$('[data-audio-mode]', els.audioModeGroup).forEach(button => setButtonState(button, button.dataset.audioMode === state.audioMode));
    setButtonState(els.protectBackground, state.protectBackground);
    els.seedInput.value = String(state.seed);
    const controls = [
      ['identityFidelity', els.identityFidelity, els.identityValue], ['lightingFidelity', els.lightingFidelity, els.lightingValue],
      ['motionFidelity', els.motionFidelity, els.motionValue], ['edgeFidelity', els.edgeFidelity, els.edgeValue], ['temporalFidelity', els.temporalFidelity, els.temporalValue],
      ['lipSync', els.lipSync, els.lipSyncValue], ['originalMix', els.originalMix, els.originalMixValue], ['voiceMix', els.voiceMix, els.voiceMixValue], ['ambientMix', els.ambientMix, els.ambientMixValue]
    ];
    controls.forEach(([key,input,output]) => { input.value = String(state[key]); output.textContent = String(state[key]); });
    const takeLabel = state.variants === 1 ? '1 TAKE' : `${state.variants} TAKES`;
    els.fidelitySummary.textContent = `${qualityLabels[state.quality].toUpperCase()} · ${takeLabel}`;
    els.qualityMark.textContent = `${qualityLabels[state.quality].toUpperCase()} · ${state.resolution.toUpperCase()} TARGET`;
    els.generateQuality.textContent = `${state.resolution.toUpperCase()} TARGET`;
    const mixDelta = state.voiceMix - state.originalMix;
    els.mixSummary.textContent = state.audioMode === 'original' ? 'ORIGINAL' : (mixDelta > 20 ? 'VOICE FORWARD' : (mixDelta < -20 ? 'SOURCE FORWARD' : 'BALANCED'));
  }

  function renderCamera() {
    $$('[data-camera]').forEach(b => { const selected = b.dataset.camera === state.camera; b.classList.toggle('selected', selected); b.setAttribute('aria-pressed', String(selected)); });
    els.cameraCopy.textContent = cameras[state.camera] || '';
  }

  function renderShotReadout() {
    els.readoutLength.textContent = `${String(state.length).padStart(2, '0')} SEC`;
    els.readoutCamera.textContent = state.camera.toUpperCase();
    els.readoutSound.textContent = state.sound ? 'SOUND' : 'SILENT';
    els.readoutSound.classList.toggle('on', state.sound);
  }

  function renderMode() {
    const isRecast = state.mode === 'recast';
    const isAnimate = state.mode === 'animate';
    els.recastSource.hidden = !isRecast;
    els.animateSource.hidden = !isAnimate;
    els.promptSource.hidden = state.mode !== 'prompt';
    els.startHeading.textContent = isRecast ? 'Performance' : (isAnimate ? 'Start frame' : 'From prompt');
    els.startEyebrow.textContent = isRecast ? 'SOURCE 01' : (isAnimate ? 'FRAME 01' : 'SOURCE 01');
    els.brandMode.textContent = isRecast ? 'RECAST' : (isAnimate ? 'REGEN' : 'PROMPT');
    els.generateLabel.textContent = isRecast ? 'Recast' : 'Regen';
    $$('.mode-switcher button').forEach(b => {
      const active = b.dataset.mode === state.mode;
      b.classList.toggle('active', active);
      b.setAttribute('aria-selected', String(active));
    });
    if (!state.hintDismissed) {
      els.firstHint.hidden = false;
      els.hintText.textContent = isRecast
        ? 'Choose a performance. Then add photos, or a video, of the person who should take their place.'
        : isAnimate
          ? 'Drop a photograph. Describe what moves. Regen keeps the still as frame one and writes the shot from there.'
          : 'Write the whole shot, or draft a still first and refine its motion in Animate.';
    } else els.firstHint.hidden = true;
    stageTakeId = null;
    renderStage();
    renderComposer();
  }

  function renderComposer() {
    if (els.motionPrompt.value !== state.prompt) els.motionPrompt.value = state.prompt;
    els.promptCount.textContent = `${state.prompt.length} / 800`;
    els.generateLength.textContent = `${state.length}s`;
    const readiness = getReadiness();
    const ready = readiness.ready;
    els.generateButton.disabled = !ready || !!activeJob;
    els.readinessCopy.textContent = readiness.message;
    els.readinessCopy.className = `readiness-copy ${ready ? 'ready' : ''}`.trim();
    els.promptHistoryCount.textContent = String(state.promptHistory.length);
    renderPromptSuggestions();
    renderStageMeta();
  }

  function getReadiness() {
    if (state.prompt.trim().length < 8) return { ready:false, status:'ADD DIRECTION', message:'Add a little more direction · 8 characters minimum' };
    if (state.mode === 'recast' && !(state.sampleId || customPerformance)) return { ready:false, status:'ADD PERFORMANCE', message:'Choose or upload a performance' };
    if (state.mode === 'recast' && personMedia.length === 0) return { ready:false, status:'ADD CAST', message:'Add at least one cast reference' };
    if (state.mode === 'animate' && !startFrame) return { ready:false, status:'ADD FRAME', message:'Add a start frame' };
    return { ready:true, status:'READY', message:`Ready to ${state.mode === 'recast' ? 'recast' : 'regen'} · video engine required` };
  }

  function getPromptSuggestions() {
    const typed = state.prompt.trim();
    if (typed.length < 8) {
      if (state.mode === 'recast') return ['Match the original timing', 'Keep eye-line and gesture', 'Preserve the camera move'];
      if (state.mode === 'animate') return ['A small breath, then turn', 'Wind moves through the fabric', 'Hold, then look to camera'];
      return ['A quiet room at blue hour', 'Walk into frame and pause', 'One precise editorial gesture'];
    }
    const cameraNotes = {
      Hold:'Locked camera, no reframing', 'Push in':'Slow push toward the subject', Orbit:'Gentle orbit, steady horizon',
      Drift:'Subtle handheld drift', Rise:'Rise slowly to reveal the space', Rack:'Rack focus into the background'
    };
    return [cameraNotes[state.camera] || 'Keep camera movement restrained', 'Keep motion natural and continuous', 'No new people, logos, or text'];
  }

  function renderPromptSuggestions() {
    const suggestions = getPromptSuggestions();
    els.promptSuggestions.innerHTML = suggestions.map(value => `<button type="button" data-prompt-suggestion="${escapeHtml(value)}">${escapeHtml(value)}</button>`).join('');
    $$('[data-prompt-suggestion]', els.promptSuggestions).forEach(button => button.addEventListener('click', () => {
      const value = button.dataset.promptSuggestion;
      state.prompt = state.prompt.trim().length < 8 ? value : `${state.prompt.trim().replace(/[,. ]+$/, '')}. ${value}.`;
      state.prompt = state.prompt.slice(0, 800);
      renderComposer();
      els.motionPrompt.focus();
      persist();
    }));
  }

  function currentRecipe() {
    return {
      id: uid(), createdAt: Date.now(), prompt: state.prompt.trim(), mode: state.mode, camera: state.camera, length: state.length, aspect: state.aspect,
      quality: state.quality, resolution: state.resolution, variants: state.variants, seed: state.seed, presentation: state.presentation,
      protectBackground: state.protectBackground, identityFidelity: state.identityFidelity, lightingFidelity: state.lightingFidelity,
      motionFidelity: state.motionFidelity, edgeFidelity: state.edgeFidelity, temporalFidelity: state.temporalFidelity,
      audioMode: state.audioMode, lipSync: state.lipSync, originalMix: state.originalMix, voiceMix: state.voiceMix, ambientMix: state.ambientMix
    };
  }

  function savePromptRecipe() {
    if (state.prompt.trim().length < 8) { toast('Add a little more direction before saving a recipe.', 'error'); return; }
    const existing = state.promptHistory.findIndex(item => item.prompt.trim().toLowerCase() === state.prompt.trim().toLowerCase());
    if (existing >= 0) state.promptHistory.splice(existing, 1);
    state.promptHistory.unshift(currentRecipe());
    state.promptHistory = state.promptHistory.slice(0, 12);
    persist(); renderComposer(); toast('Shot recipe saved in this browser.', 'ok');
  }

  function renderPromptHistory() {
    els.promptHistoryCount.textContent = String(state.promptHistory.length);
    els.promptHistoryEmpty.hidden = state.promptHistory.length > 0;
    els.promptHistoryList.hidden = state.promptHistory.length === 0;
    els.promptHistoryList.innerHTML = state.promptHistory.map((recipe, index) => {
      const stamp = new Date(recipe.createdAt || Date.now()).toLocaleString([], { month:'short', day:'numeric', hour:'numeric', minute:'2-digit' });
      return `<article class="recipe-item" data-recipe-index="${index}"><div class="recipe-item-head"><span>${escapeHtml(recipe.mode)} · ${escapeHtml(recipe.quality || 'high')}</span><span>${escapeHtml(stamp)}</span></div><p>${escapeHtml(recipe.prompt)}</p><div class="recipe-tags"><span>${escapeHtml(String(recipe.length || 6))} sec</span><span>${escapeHtml(recipe.camera || 'Drift')}</span><span>${escapeHtml(recipe.resolution || '1080p')} target</span><span>Seed ${escapeHtml(String(recipe.seed || '—'))}</span></div><div class="recipe-actions"><button class="button primary" data-recipe-use>Load recipe</button><button class="button secondary" data-recipe-copy>Copy direction</button><button class="icon-button" data-recipe-remove aria-label="Remove saved direction"><svg><use href="#i-trash"/></svg></button></div></article>`;
    }).join('');
    $$('.recipe-item', els.promptHistoryList).forEach(card => {
      const index = Number(card.dataset.recipeIndex);
      $('[data-recipe-use]', card).addEventListener('click', () => loadPromptRecipe(index));
      $('[data-recipe-copy]', card).addEventListener('click', () => copyPromptRecipe(index));
      $('[data-recipe-remove]', card).addEventListener('click', () => { state.promptHistory.splice(index, 1); persist(); renderPromptHistory(); renderComposer(); toast('Saved direction removed.'); });
    });
  }

  function loadPromptRecipe(index) {
    const recipe = state.promptHistory[index];
    if (!recipe) return;
    const keys = ['prompt','mode','camera','length','aspect','quality','resolution','variants','seed','presentation','protectBackground','identityFidelity','lightingFidelity','motionFidelity','edgeFidelity','temporalFidelity','audioMode','lipSync','originalMix','voiceMix','ambientMix'];
    keys.forEach(key => { if (recipe[key] !== undefined) state[key] = recipe[key]; });
    closePromptHistory(); renderOptions(); renderAdvanced(); renderMode(); renderVoice(); renderComposer(); persist();
    toast('Recipe loaded. Source media stays unchanged.', 'ok');
  }

  async function copyPromptRecipe(index) {
    const recipe = state.promptHistory[index];
    if (!recipe) return;
    try { await navigator.clipboard.writeText(recipe.prompt); toast('Direction copied.', 'ok'); }
    catch (_) { toast('Copy is blocked in this browser. Load the recipe and copy from the prompt.', 'error'); }
  }

  function openPromptHistory() {
    renderPromptHistory();
    if (typeof els.promptHistoryDialog.showModal === 'function') els.promptHistoryDialog.showModal(); else els.promptHistoryDialog.setAttribute('open', '');
  }

  function closePromptHistory() {
    if (els.promptHistoryDialog.open && typeof els.promptHistoryDialog.close === 'function') els.promptHistoryDialog.close(); else els.promptHistoryDialog.removeAttribute('open');
  }

  function renderVoice() {
    els.spokenLine.value = state.spokenLine;
    els.spokenCount.textContent = `${state.spokenLine.length} / 240`;
    setButtonState(els.soundToggle, state.sound);
    els.soundState.textContent = state.sound ? 'On' : 'Off';
    els.soundToggle.disabled = !!voiceBlob || state.spokenLine.trim().length > 0;
    els.voicePreview.hidden = !voiceBlob;
    renderShotReadout();
  }

  function applyDeliveryTag(tag) {
    const marker = `[${tag}]`;
    const cleaned = state.spokenLine.replace(/^\[(calm|close|urgent|whisper)\]\s*/i, '').trimStart();
    state.spokenLine = `${marker} ${cleaned}`.slice(0, 240);
    state.sound = true;
    renderVoice(); persist(); els.spokenLine.focus();
  }

  function auditionSpokenLine() {
    if (!('speechSynthesis' in window) || !window.SpeechSynthesisUtterance) { toast('Browser voice audition is not available here.', 'error'); return; }
    if (speechSynthesis.speaking) { speechSynthesis.cancel(); els.auditionVoice.textContent = 'Audition'; return; }
    const text = state.spokenLine.replace(/\[[^\]]+\]/g, '').trim();
    if (!text) { toast('Add a spoken line before auditioning it.', 'error'); return; }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = /\[urgent\]/i.test(state.spokenLine) ? 1.08 : (/\[close\]/i.test(state.spokenLine) ? .94 : 1);
    utterance.volume = /\[whisper\]/i.test(state.spokenLine) ? .5 : .9;
    utterance.onend = utterance.onerror = () => { els.auditionVoice.textContent = 'Audition'; };
    els.auditionVoice.textContent = 'Stop';
    speechSynthesis.speak(utterance);
  }

  function clearStageMedia() {
    els.stage.classList.remove('empty', 'holding', 'comparing');
    els.stageArt.hidden = true;
    els.stageImage.hidden = true;
    els.stageVideo.hidden = true;
    els.holdImage.hidden = true;
    els.compareRange.hidden = true;
    els.compareHandle.hidden = true;
    els.stageBusy.hidden = true;
    els.stageMessage.hidden = true;
    els.stageVideo.pause();
    els.stageVideo.removeAttribute('src');
    els.stageTimecode.textContent = '00:00:00:00';
    const compareButton = $('[data-stage-action="compare"]', els.stageActions);
    if (compareButton) compareButton.textContent = 'Compare';
  }

  function setStageAspect(aspect = state.aspect) {
    let normalized = aspect;
    if (!['16:9','9:16','1:1'].includes(normalized) && /^\d+:\d+$/.test(String(normalized))) {
      const [w,h] = String(normalized).split(':').map(Number);
      normalized = ratioLabel(w,h);
    }
    if (!['16:9','9:16','1:1'].includes(normalized)) normalized = state.aspect;
    els.stage.dataset.aspect = normalized;
    els.stageDimensions.textContent = normalized;
  }

  function renderStageMeta() {
    const take = state.library.find(t => t.id === stageTakeId);
    const sourceAspect = state.mode === 'animate' && startFrame
      ? startFrame.aspect
      : state.mode === 'recast'
        ? (customPerformance ? ratioLabel(customPerformance.width, customPerformance.height) : '16:9')
        : state.aspect;
    setStageAspect(take?.displayAspect || take?.aspect || sourceAspect);
    els.stageCameraMeta.textContent = state.camera.toUpperCase();
    if (take) {
      els.stageLabel.textContent = `${take.mode.toUpperCase()} · ${take.status.toUpperCase()}`;
      els.stageStatus.textContent = take.status === 'done' ? `${Math.round(take.length)}S` : take.status.toUpperCase();
      els.stageStatus.className = 'stage-status';
    } else {
      els.stageLabel.textContent = state.mode === 'recast' ? 'FRAME 01 · PERFORMANCE' : (state.mode === 'animate' ? 'FRAME 01 · SOURCE' : 'FRAME 01 · PROMPT');
      const readiness = getReadiness();
      els.stageStatus.textContent = readiness.status;
      els.stageStatus.className = `stage-status ${readiness.ready ? '' : 'pending'}`.trim();
    }
    els.stageSourceMeta.textContent = take ? 'SOURCE / LOCAL' : (customPerformance ? 'SOURCE / CUSTOM' : 'SOURCE / NATIVE');
  }

  async function renderStage() {
    clearStageMedia();
    const take = state.library.find(t => t.id === stageTakeId);
    if (take) {
      const url = await resolveTakeUrl(take);
      if (stageTakeId !== take.id) return;
      if (url) {
        els.stageVideo.src = url;
        els.stageVideo.hidden = false;
      } else if (take.poster) {
        els.stageImage.src = take.poster;
        els.stageImage.hidden = false;
        showStageMessage('Select the original file again to play this saved take.');
      } else showStageMessage('Select the original file again to play this saved take.');
      els.stageCaption.textContent = take.name;
      if (take.sourcePoster || take.poster) { els.holdImage.src = take.sourcePoster || take.poster; els.holdImage.hidden = false; }
      els.stageActions.hidden = false;
      $('[data-stage-action="pieces"]', els.stageActions).hidden = !(take.pieces > 1);
      $('[data-stage-action="compare"]', els.stageActions).hidden = !take.poster;
    } else if (state.mode === 'animate' && startFrame) {
      els.stageImage.src = startFrame.url;
      els.stageImage.hidden = false;
      els.stageCaption.textContent = startFrame.name;
      els.stageActions.hidden = true;
    } else if (state.mode === 'recast') {
      if (customPerformance) {
        els.stageImage.src = customPerformance.url;
        els.stageImage.hidden = false;
        els.stageCaption.textContent = `${customPerformance.name} · opening frame`;
      } else {
        const p = performances.find(item => item.id === state.sampleId);
        if (p) {
          els.stageArt.className = `stage-art ${p.art}`;
          els.stageArt.hidden = false;
          els.stageArt.setAttribute('aria-label', `${p.name} performance first frame`);
          els.stageCaption.textContent = `${p.name} · first frame`;
        } else {
          els.stage.classList.add('empty');
          els.stageCaption.textContent = 'No performance selected';
          showStageMessage('Choose a performance, or upload your own.');
        }
      }
      els.stageActions.hidden = true;
    } else {
      els.stage.classList.add('empty');
      els.stageCaption.textContent = state.mode === 'animate' ? 'No start frame yet' : 'Direction only · no still yet';
      showStageMessage(state.mode === 'animate' ? 'Add a photograph to hold as frame one.' : 'Write the shot below, or draft a still.');
      els.stageActions.hidden = true;
    }
    renderStageMeta();
  }

  function showStageMessage(message) {
    els.stageMessage.hidden = false;
    $('p', els.stageMessage).textContent = message;
  }

  function renderPeople() {
    els.castCount.textContent = `${personMedia.length} / 3`;
    els.personStrip.innerHTML = '';
    personMedia.forEach((item, index) => {
      const node = document.createElement('div');
      node.className = 'person-thumb';
      node.innerHTML = `<img alt="Person reference ${index + 1}" src="${item.url}"><button aria-label="Remove person reference ${index + 1}"><svg><use href="#i-close"/></svg></button>`;
      $('button', node).addEventListener('click', () => {
        if (remakeCharacter?.source === 'studio' && remakeCharacter.ref === item) setRemakeCharacter(null);
        if (item.ownedUrl) URL.revokeObjectURL(item.url);
        personMedia.splice(index, 1);
        renderPeople(); renderComposer();
      });
      els.personStrip.append(node);
    });
    els.personUpload.disabled = personMedia.length >= 3;
    if (els.useStudioCast) els.useStudioCast.disabled = personMedia.length === 0;
  }

  function renderStartFrame() {
    els.startUpload.hidden = !!startFrame;
    els.startPreview.hidden = !startFrame;
    els.startPreview.innerHTML = startFrame ? `<img src="${startFrame.url}" alt="Start frame"><button class="icon-button" aria-label="Remove start frame"><svg><use href="#i-close"/></svg></button>` : '';
    if (startFrame) $('button', els.startPreview).addEventListener('click', () => {
      if (startFrame.ownedUrl) URL.revokeObjectURL(startFrame.url);
      startFrame = null; renderStartFrame(); renderComposer(); renderStage();
    });
    els.endFileChip.hidden = !endFrame;
    els.endFileChip.innerHTML = endFrame ? `${escapeHtml(endFrame.name)} <button class="text-button danger-text" type="button">Clear</button>` : '';
    if (endFrame) $('button', els.endFileChip).addEventListener('click', () => { if (endFrame.ownedUrl) URL.revokeObjectURL(endFrame.url); endFrame = null; renderStartFrame(); });
  }

  function escapeHtml(value) {
    const div = document.createElement('div'); div.textContent = String(value); return div.innerHTML;
  }

  function renderStatus() {
    const count = activeJob ? 1 : state.library.length;
    els.libraryCount.textContent = count;
    els.statusLabel.textContent = activeJob ? 'WORKING' : 'IDLE';
    els.statusCopy.textContent = activeJob ? `${activeJob.status} · ${activeJob.mode}` : 'Nothing in progress';
    els.systemStatus.classList.toggle('working', !!activeJob);
    const libraryNav = $('.nav-item[data-section="library"]');
    libraryNav.classList.toggle('working', !!activeJob);
    els.libraryStat.textContent = `${state.library.length} ${state.library.length === 1 ? 'TAKE' : 'TAKES'}`;
  }

  function renderFilmstrip() {
    els.filmstrip.innerHTML = '';
    state.library.forEach(take => {
      const button = document.createElement('button');
      button.className = `film-thumb ${stageTakeId === take.id ? 'active' : ''}`;
      button.setAttribute('aria-label', `Open ${take.name}`);
      button.innerHTML = take.poster ? `<img src="${take.poster}" alt="">` : '';
      button.addEventListener('click', () => { stageTakeId = take.id; renderStage(); renderFilmstrip(); });
      els.filmstrip.append(button);
    });
  }

  async function renderLibrary() {
    renderStatus();
    const query = libraryQuery.trim().toLowerCase();
    const takes = state.library.filter(take => {
      const filterMatch = libraryFilter === 'all' || (libraryFilter === 'favorite' ? take.favorite : take.mode.toLowerCase() === libraryFilter);
      const queryMatch = !query || `${take.name} ${take.prompt || ''} ${take.mode}`.toLowerCase().includes(query);
      return filterMatch && queryMatch;
    });
    els.libraryEmpty.hidden = state.library.length > 0;
    els.libraryGrid.hidden = state.library.length === 0;
    els.libraryGrid.innerHTML = '';
    $$('[data-library-filter]').forEach(button => button.classList.toggle('active', button.dataset.libraryFilter === libraryFilter));
    if (state.library.length && !takes.length) {
      els.libraryGrid.innerHTML = '<div class="no-results">No takes match this filter.</div>';
      return;
    }
    for (const take of takes) {
      const available = !!(await resolveTakeUrl(take));
      const card = document.createElement('article');
      card.className = `take-card ${take.favorite ? 'favorite' : ''}`.trim();
      card.innerHTML = `
        <div class="take-poster">${take.poster ? `<img src="${take.poster}" alt="Poster for ${escapeHtml(take.name)}">` : ''}<span class="take-badge">${escapeHtml(take.mode)}</span><button class="favorite-button ${take.favorite ? 'active' : ''}" data-favorite aria-pressed="${String(!!take.favorite)}" aria-label="${take.favorite ? 'Remove from' : 'Add to'} favorites"><svg><use href="#i-star"/></svg></button></div>
        <div class="take-body"><div class="take-meta"><span>${available ? escapeHtml(take.status) : 'relink needed'}</span><span>${formatTime(take.length)}</span></div><p class="take-prompt">${escapeHtml(take.prompt || 'Copied video')}</p><div class="take-actions"><button class="button secondary" data-open>${available ? 'Play' : 'Relink'}</button><button class="button secondary" data-download ${available ? '' : 'disabled'}>Download</button><button class="icon-button" data-remove aria-label="Remove ${escapeHtml(take.name)}"><svg><use href="#i-trash"/></svg></button></div></div>`;
      $('[data-favorite]', card).addEventListener('click', () => { take.favorite = !take.favorite; persist(); renderLibrary(); renderFilmstrip(); toast(take.favorite ? 'Saved to favorites.' : 'Removed from favorites.'); });
      $('[data-open]', card).addEventListener('click', () => available ? openTake(take.id, true) : beginRelink(take.id));
      $('[data-download]', card).addEventListener('click', () => downloadTake(take));
      $('[data-remove]', card).addEventListener('click', () => removeTake(take.id));
      els.libraryGrid.append(card);
    }
  }

  function beginRelink(id) { relinkTakeId = id; els.relinkInput.click(); }

  async function handleRelink(file) {
    const take = state.library.find(item => item.id === relinkTakeId);
    relinkTakeId = null;
    if (!take || !file) return;
    let meta;
    try { meta = await inspectVideo(file); } catch (_) { toast('That replacement video could not be read.', 'error'); return; }
    if (file.size > 250 * 1024 * 1024 || meta.duration > 900.1) { toast('Keep the replacement under 250 MB and 15 minutes.', 'error'); return; }
    try { await idbPut(take.mediaKey || (take.mediaKey = uid()), file); }
    catch (_) { toast('This browser could not store the replacement video.', 'error'); return; }
    if (liveUrls.has(take.id)) URL.revokeObjectURL(liveUrls.get(take.id));
    liveUrls.set(take.id, URL.createObjectURL(file));
    take.fileName = file.name; take.name = file.name; take.length = meta.duration; take.aspect = `${meta.width}:${meta.height}`; take.displayAspect = ratioLabel(meta.width, meta.height);
    const frames = await extractVideoFrames(file, [.03], 480).catch(() => []);
    if (frames[0]) take.poster = await blobToDataUrl(frames[0]);
    persist(); await renderLibrary(); renderFilmstrip(); toast('The saved take is linked again.', 'ok');
  }

  function navigate(section) {
    if (section === 'apps') { openApps(); return; }
    $$('[data-section-panel]').forEach(panel => { panel.hidden = panel.dataset.sectionPanel !== section; panel.classList.toggle('active', panel.dataset.sectionPanel === section); });
    $$('.nav-item').forEach(item => {
      const active = item.dataset.section === section;
      item.classList.toggle('active', active);
      if (active) item.setAttribute('aria-current', 'page'); else item.removeAttribute('aria-current');
    });
    if (section === 'library') renderLibrary();
    if (section === 'preview') renderRemakeWorkspace();
    if (section !== 'preview' && previewStream) stopCamera();
    closeDrawer();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function openTake(id, autoplay = false) {
    stageTakeId = id;
    navigate('studio');
    await renderStage(); renderFilmstrip();
    if (autoplay && !els.stageVideo.hidden) els.stageVideo.play().catch(() => {});
  }

  async function removeTake(id) {
    const index = state.library.findIndex(t => t.id === id);
    if (index < 0) return;
    const [take] = state.library.splice(index, 1);
    if (take.mediaKey) await idbDelete(take.mediaKey).catch(() => {});
    if (liveUrls.has(id)) { URL.revokeObjectURL(liveUrls.get(id)); liveUrls.delete(id); }
    if (stageTakeId === id) stageTakeId = state.library[index]?.id || state.library[index - 1]?.id || null;
    persist(); renderLibrary(); renderFilmstrip(); renderStage();
    toast('The take was removed.');
  }

  async function downloadTake(take) {
    const url = await resolveTakeUrl(take);
    if (!url) { toast('Select the original file again before downloading this take.', 'error'); return; }
    const a = document.createElement('a');
    a.href = url; a.download = take.fileName || `frameshift-${take.mode.toLowerCase()}.mp4`; document.body.append(a); a.click(); a.remove();
  }

  function closeDrawer() {
    els.sideNav.classList.remove('open'); els.scrim.hidden = true; els.menuTrigger.setAttribute('aria-expanded', 'false');
    if (window.innerWidth <= 760) { els.sideNav.inert = true; els.sideNav.setAttribute('aria-hidden', 'true'); }
  }
  function openDrawer() {
    els.sideNav.inert = false; els.sideNav.removeAttribute('aria-hidden');
    els.sideNav.classList.add('open'); els.scrim.hidden = false; els.menuTrigger.setAttribute('aria-expanded', 'true');
    $('.nav-item', els.sideNav)?.focus();
  }
  function syncDrawerA11y() {
    if (window.innerWidth > 760) { els.sideNav.inert = false; els.sideNav.removeAttribute('aria-hidden'); els.scrim.hidden = true; }
    else if (!els.sideNav.classList.contains('open')) closeDrawer();
  }

  async function handlePersonFile(file) {
    if (!file || file.size === 0) { toast('Choose a photo or video that contains a picture.', 'error'); return; }
    if (/^image\/(jpeg|png|webp)$/i.test(file.type)) {
      if (personMedia.length >= 3) return;
      let meta;
      try { meta = await inspectImageFile(file); } catch (_) { toast('That image could not be decoded.', 'error'); return; }
      personMedia.push({ url: URL.createObjectURL(file), name: file.name, ownedUrl: true, ...meta });
      renderPeople(); renderComposer();
      return;
    }
    if (file.type.startsWith('video/') || /\.(mp4|webm|mov|mkv|m4v)$/i.test(file.name)) {
      if (file.size > 250 * 1024 * 1024) { toast('Keep a cast video under 250 MB.', 'error'); return; }
      try {
        const meta = await inspectVideo(file);
        if (meta.duration > 900.1) { toast('A cast video can be up to 15 minutes.', 'error'); return; }
        const frames = await extractVideoFrames(file, [0.12, 0.5, 0.88], 420);
        personMedia.forEach(item => item.ownedUrl && URL.revokeObjectURL(item.url));
        personMedia = frames.slice(0, 3).map((blob, i) => ({ url: URL.createObjectURL(blob), name: `${file.name} · ${i + 1}`, ownedUrl: true }));
        renderPeople(); renderComposer(); toast('Three reference frames were taken from the video.', 'ok');
      } catch (_) { toast('That video could not be read. Try an MP4 or WebM file.', 'error'); }
      return;
    }
    toast('Choose a JPG, PNG, WebP, or video file.', 'error');
  }

  async function handleImageFile(file, kind) {
    if (!file || file.size === 0 || !/^image\/(jpeg|png|webp)$/i.test(file.type)) { toast('Use a JPG, PNG, or WebP photograph.', 'error'); return; }
    let meta;
    try { meta = await inspectImageFile(file); } catch (_) { toast('That image could not be decoded.', 'error'); return; }
    const item = { url: URL.createObjectURL(file), name: file.name, ownedUrl: true, ...meta };
    if (kind === 'start') { if (startFrame?.ownedUrl) URL.revokeObjectURL(startFrame.url); startFrame = item; }
    else { if (endFrame?.ownedUrl) URL.revokeObjectURL(endFrame.url); endFrame = item; }
    renderStartFrame(); renderComposer(); renderStage();
  }

  function inspectImageFile(file) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const image = new Image();
      const timeout = setTimeout(() => { URL.revokeObjectURL(url); reject(new Error('timeout')); }, 10000);
      image.onload = () => {
        clearTimeout(timeout); URL.revokeObjectURL(url);
        if (!image.naturalWidth || !image.naturalHeight) { reject(new Error('empty')); return; }
        resolve({ width:image.naturalWidth, height:image.naturalHeight, aspect:ratioLabel(image.naturalWidth, image.naturalHeight) });
      };
      image.onerror = () => { clearTimeout(timeout); URL.revokeObjectURL(url); reject(new Error('unreadable')); };
      image.src = url;
    });
  }

  async function inspectVideo(file) {
    return new Promise((resolve, reject) => {
      const video = document.createElement('video');
      const url = URL.createObjectURL(file);
      let settled = false;
      const finish = (fn, value) => { if (settled) return; settled = true; clearTimeout(timeout); URL.revokeObjectURL(url); fn(value); };
      const timeout = setTimeout(() => finish(reject, new Error('timeout')), 10000);
      video.preload = 'metadata';
      video.onloadedmetadata = () => {
        const result = { duration:video.duration, width:video.videoWidth, height:video.videoHeight };
        if (!Number.isFinite(result.duration) || result.duration <= 0 || !result.width || !result.height) finish(reject, new Error('empty'));
        else finish(resolve, result);
      };
      video.onerror = () => finish(reject, new Error('unreadable'));
      video.src = url;
    });
  }

  async function extractVideoFrames(file, points = [0.05], width = 960) {
    const url = URL.createObjectURL(file);
    const video = document.createElement('video');
    video.muted = true; video.playsInline = true; video.preload = 'auto'; video.src = url;
    try {
      await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error('timeout')), 10000);
        video.onloadedmetadata = () => { clearTimeout(timeout); video.videoWidth && video.videoHeight ? resolve() : reject(new Error('empty')); };
        video.onerror = () => { clearTimeout(timeout); reject(new Error('unreadable')); };
      });
      const canvas = document.createElement('canvas');
      const ratio = video.videoHeight / video.videoWidth;
      canvas.width = Math.min(width, video.videoWidth); canvas.height = Math.max(1, Math.round(canvas.width * ratio));
      const ctx = canvas.getContext('2d');
      const blobs = [];
      for (const point of points) {
        const target = clamp(video.duration * point, 0, Math.max(0, video.duration - 0.05));
        await new Promise((resolve, reject) => {
          const timeout = setTimeout(() => reject(new Error('seek timeout')), 6000);
          video.onseeked = () => { clearTimeout(timeout); resolve(); };
          video.onerror = () => { clearTimeout(timeout); reject(new Error('unreadable')); };
          video.currentTime = target;
        });
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', .76));
        if (blob) blobs.push(blob);
      }
      return blobs;
    } finally { URL.revokeObjectURL(url); }
  }

  async function handleCopyVideo(file) {
    const extOk = /\.(mp4|webm|mov|mkv|m4v)$/i.test(file?.name || '');
    if (!file || file.size === 0) { toast('That file is empty.', 'error'); return; }
    if (!(file.type.startsWith('video/') || extOk)) { toast('That file has no picture.', 'error'); return; }
    if (file.size > 250 * 1024 * 1024) { toast('Keep a copied video under 250 MB.', 'error'); return; }
    let meta;
    try { meta = await inspectVideo(file); } catch (_) { toast('That file has no picture.', 'error'); return; }
    if (!Number.isFinite(meta.duration) || meta.duration <= 0) { toast('That file is empty.', 'error'); return; }
    if (meta.duration > 900.1) { toast('A copy can be up to 15 minutes. Split a longer video first.', 'error'); return; }
    const posterFrames = await extractVideoFrames(file, [0.03], 480).catch(() => []);
    const poster = posterFrames[0] ? await blobToDataUrl(posterFrames[0]) : null;
    const take = {
      id: uid(), mediaKey: uid(), fileName: file.name, name: file.name, status: 'done', mode: 'Copy', length: meta.duration,
      prompt: 'Local copy · piece markers every 15 seconds', aspect: meta.width && meta.height ? `${meta.width}:${meta.height}` : state.aspect, displayAspect:ratioLabel(meta.width, meta.height), upscaled: false,
      pieces: Math.max(1, Math.ceil(meta.duration / 15)), poster, createdAt: Date.now(), favorite: false,
      seed: state.seed, quality: state.quality, resolution: state.resolution
    };
    try { await idbPut(take.mediaKey, file); }
    catch (_) { toast('This browser could not store that video. Free some browser storage and try again.', 'error'); return; }
    const url = URL.createObjectURL(file); liveUrls.set(take.id, url);
    copiedVideo = { ...take, url, file };
    state.library.unshift(take);
    const overflow = state.library.splice(16);
    overflow.forEach(old => old.mediaKey && idbDelete(old.mediaKey).catch(() => {}));
    stageTakeId = take.id;
    if (state.mode === 'animate' && poster) { startFrame = { url: poster, name: `${file.name} · opening frame`, ownedUrl: false }; renderStartFrame(); }
    persist(); renderCopiedFile(); renderLibrary(); renderFilmstrip(); renderStage(); renderComposer();
    toast(`${take.pieces} ${take.pieces === 1 ? 'piece marker' : 'piece markers'} prepared. The original video is unchanged.`, 'ok');
    sendFrameShiftNotification('Take prepared', `${file.name} is ready in the FrameShift library.`, 'frameshift-take-ready');
  }

  function renderCopiedFile() {
    els.copiedFile.hidden = !copiedVideo;
    if (!copiedVideo) { els.copiedFile.innerHTML = ''; return; }
    els.copiedFile.innerHTML = `<span><strong>${escapeHtml(copiedVideo.name)}</strong><small>${formatTime(copiedVideo.length)} · ${copiedVideo.pieces} ${copiedVideo.pieces === 1 ? 'piece marker' : 'piece markers'}</small></span><button aria-label="Clear copied video"><svg><use href="#i-close"/></svg></button><button class="button secondary" data-play-copy>Play</button><button class="button secondary" data-play-pieces>Play markers</button>`;
    $('button[aria-label]', els.copiedFile).addEventListener('click', () => { copiedVideo = null; renderCopiedFile(); });
    $('[data-play-copy]', els.copiedFile).addEventListener('click', () => { stageTakeId = copiedVideo.id; renderStage().then(() => els.stageVideo.play().catch(() => {})); });
    $('[data-play-pieces]', els.copiedFile).addEventListener('click', () => playPieces(copiedVideo));
  }

  async function playPieces(take) {
    stageTakeId = take.id; await renderStage();
    const video = els.stageVideo; let piece = 1;
    const announce = () => { els.stageStatus.textContent = `PIECE ${piece} OF ${take.pieces}`; };
    announce(); video.currentTime = 0; await video.play().catch(() => {});
    const handler = () => { const current = Math.min(take.pieces, Math.floor(video.currentTime / 15) + 1); if (current !== piece) { piece = current; announce(); } };
    video.addEventListener('timeupdate', handler);
    video.addEventListener('ended', () => { video.removeEventListener('timeupdate', handler); renderStageMeta(); }, { once: true });
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(blob); });
  }

  function submitGeneration() {
    if (els.generateButton.disabled) return;
    const message = 'Video engine not connected. Your shot is ready; connect a compatible video model to render it.';
    showStageMessage(message);
    els.stageStatus.textContent = 'ENGINE OFFLINE';
    els.stageStatus.className = 'stage-status error';
    els.readinessCopy.textContent = 'Shot ready · video engine not connected';
    els.readinessCopy.className = 'readiness-copy error';
    toast(message, 'error');
  }

  async function startVoiceRecording() {
    if (mediaRecorder?.state === 'recording') { mediaRecorder.stop(); return; }
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) { toast('Voice recording is not available in this browser.', 'error'); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const chunks = [];
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.ondataavailable = event => { if (event.data.size) chunks.push(event.data); };
      mediaRecorder.onstop = () => {
        stream.getTracks().forEach(t => t.stop()); clearInterval(recordTimer); recordTimer = null;
        const blob = new Blob(chunks, { type: mediaRecorder.mimeType || 'audio/webm' });
        els.recordVoice.innerHTML = '<svg><use href="#i-mic"/></svg>Record'; els.voiceTimer.textContent = 'OPTIONAL';
        if (!blob.size) { toast('The recording is empty.', 'error'); return; }
        if (blob.size > 4.5 * 1024 * 1024) { toast('Keep the voice recording under about 4 MB.', 'error'); return; }
        attachVoice(blob);
      };
      mediaRecorder.start(250); recordingStarted = Date.now();
      els.recordVoice.innerHTML = '<svg><use href="#i-pause"/></svg>Stop';
      recordTimer = setInterval(() => {
        const elapsed = Math.min(15, (Date.now() - recordingStarted) / 1000);
        els.voiceTimer.textContent = `${elapsed.toFixed(1)}S`;
        if (elapsed >= 15 && mediaRecorder.state === 'recording') mediaRecorder.stop();
      }, 100);
    } catch (_) { toast('Microphone access is needed to record a voice.', 'error'); }
  }

  function attachVoice(blob) {
    if (voiceUrl) URL.revokeObjectURL(voiceUrl);
    voiceBlob = blob; voiceUrl = URL.createObjectURL(blob); els.voiceAudio.src = voiceUrl;
    state.sound = true; renderVoice(); persist();
  }

  function handleVoiceFile(file) {
    const extensionOk = /\.(mp3|wav|m4a|aac|ogg|webm|flac)$/i.test(file?.name || '');
    if (!file || file.size === 0) { toast('The audio file is empty.', 'error'); return; }
    if (!(file.type.startsWith('audio/') || extensionOk)) { toast('Use an audio file.', 'error'); return; }
    if (file.size > 4.5 * 1024 * 1024) { toast('Keep the voice file under about 4 MB.', 'error'); return; }
    attachVoice(file);
  }

  function clearVoice() {
    if (voiceUrl) URL.revokeObjectURL(voiceUrl); voiceUrl = null; voiceBlob = null; els.voiceAudio.removeAttribute('src'); renderVoice();
  }

  function notificationsSupported() { return 'Notification' in window && 'serviceWorker' in navigator; }

  function renderNotificationState() {
    const supported = notificationsSupported();
    const permission = supported ? Notification.permission : 'unsupported';
    if (!supported) {
      state.notificationsEnabled = false;
      els.notificationOption.disabled = true;
      els.notificationCopy.textContent = 'Not supported in this browser';
      els.notificationState.textContent = 'N/A';
    } else if (permission === 'denied') {
      state.notificationsEnabled = false;
      els.notificationOption.disabled = false;
      els.notificationCopy.textContent = 'Blocked in browser settings';
      els.notificationState.textContent = 'BLOCKED';
    } else {
      els.notificationOption.disabled = false;
      const active = permission === 'granted' && state.notificationsEnabled;
      els.notificationCopy.textContent = active ? 'Take-ready alerts are on' : 'Get a signal when a take is ready';
      els.notificationState.textContent = active ? 'ON' : 'OFF';
      els.notificationState.classList.toggle('on', active);
    }
    els.notificationOption.setAttribute('aria-pressed', String(supported && permission === 'granted' && state.notificationsEnabled));
  }

  async function sendFrameShiftNotification(title, body, tag = 'frameshift-status') {
    if (!notificationsSupported() || Notification.permission !== 'granted' || !state.notificationsEnabled) return false;
    const options = {
      body, tag, renotify:true,
      icon:'./assets/app/frameshift-icon-192.png',
      badge:'./assets/app/frameshift-icon-64.png',
      data:{ url:'./' }
    };
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      if (registration) { await registration.showNotification(title, options); return true; }
      new Notification(title, options); return true;
    } catch (_) { return false; }
  }

  async function toggleNotifications() {
    if (!notificationsSupported()) { toast('Notifications are not supported in this browser.', 'error'); return; }
    if (Notification.permission === 'denied') { renderNotificationState(); toast('Allow notifications for FrameShift in your browser settings.', 'error'); return; }
    if (Notification.permission === 'default') {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') { state.notificationsEnabled = false; persist(); renderNotificationState(); return; }
      state.notificationsEnabled = true;
    } else state.notificationsEnabled = !state.notificationsEnabled;
    persist(); renderNotificationState();
    if (state.notificationsEnabled) {
      toast('Render-ready notifications are on.', 'ok');
      await sendFrameShiftNotification('FrameShift notifications are on', 'Take-ready alerts will appear here.', 'frameshift-enabled');
    } else toast('Notifications are off.');
  }

  function openApps() { renderNotificationState(); if (typeof els.appSheet.showModal === 'function') els.appSheet.showModal(); else els.appSheet.setAttribute('open', ''); closeDrawer(); }
  function closeApps() { if (els.appSheet.open && typeof els.appSheet.close === 'function') els.appSheet.close(); else els.appSheet.removeAttribute('open'); }

  async function startCamera() {
    if (cameraStarting || previewStream) return;
    if (!navigator.mediaDevices?.getUserMedia) { toast('Camera preview is not available in this browser.', 'error'); return; }
    cameraStarting = true; els.toggleCamera.disabled = true;
    let stream = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode }, audio: false });
      previewStream = stream;
      els.cameraVideo.srcObject = previewStream; await els.cameraVideo.play();
      els.cameraOff.hidden = true; els.toggleCamera.innerHTML = '<svg><use href="#i-camera"/></svg>Stop camera'; els.toggleMic.disabled = false; els.flipCamera.disabled = false;
      els.cameraFacing.textContent = facingMode === 'user' ? 'FRONT' : 'BACK'; els.cameraVideo.style.transform = facingMode === 'user' ? 'scaleX(-1)' : 'none';
      measureFps();
    } catch (_) { stream?.getTracks().forEach(track => track.stop()); previewStream = null; toast('Camera access is needed for live preview.', 'error'); }
    finally { cameraStarting = false; els.toggleCamera.disabled = false; }
  }

  function stopCamera() {
    previewStream?.getTracks().forEach(t => t.stop()); previewStream = null; els.cameraVideo.srcObject = null; els.cameraOff.hidden = false;
    els.toggleCamera.innerHTML = '<svg><use href="#i-camera"/></svg>Start camera'; els.toggleMic.disabled = true; els.flipCamera.disabled = true; els.fpsReadout.textContent = '0'; fpsFrames = [];
    micEnabled = false; els.toggleMic.innerHTML = '<svg><use href="#i-mic"/></svg>Microphone off';
  }

  function measureFps() {
    if (!previewStream || !els.cameraVideo.requestVideoFrameCallback) return;
    const tick = (now) => {
      if (!previewStream) return;
      fpsFrames.push(now); fpsFrames = fpsFrames.filter(t => now - t <= 1000); els.fpsReadout.textContent = String(Math.max(0, fpsFrames.length - 1));
      els.cameraVideo.requestVideoFrameCallback(tick);
    };
    els.cameraVideo.requestVideoFrameCallback(tick);
  }

  async function flipCamera() { facingMode = facingMode === 'user' ? 'environment' : 'user'; stopCamera(); await startCamera(); }

  async function updateMic() {
    if (!previewStream) return;
    if (!micEnabled) {
      try {
        const audioStream = await navigator.mediaDevices.getUserMedia({ audio:true, video:false });
        audioStream.getAudioTracks().forEach(track => previewStream.addTrack(track));
        micEnabled = true;
      } catch (_) { toast('Microphone access is needed to monitor room sound.', 'error'); return; }
    } else {
      previewStream.getAudioTracks().forEach(track => { track.stop(); previewStream.removeTrack(track); });
      micEnabled = false;
    }
    els.toggleMic.innerHTML = `<svg><use href="#i-mic"/></svg>Microphone ${micEnabled ? 'on' : 'off'}`;
    els.deviceNote.textContent = micEnabled ? 'The microphone track is included; the monitor stays muted.' : 'The monitor stays muted to prevent feedback.';
  }

  function youtubeIdFromUrl(url) {
    const host = url.hostname.replace(/^www\./, '').toLowerCase();
    if (host === 'youtu.be') return url.pathname.split('/').filter(Boolean)[0] || '';
    if (host === 'youtube.com' || host.endsWith('.youtube.com')) {
      if (url.searchParams.get('v')) return url.searchParams.get('v');
      const parts = url.pathname.split('/').filter(Boolean);
      if (['embed', 'shorts', 'live'].includes(parts[0])) return parts[1] || '';
    }
    return '';
  }

  function parseRemakeRuntime(value = els.remakeDuration.value) {
    const match = String(value).trim().match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return 0;
    const minutes = Number(match[1]);
    const seconds = Number(match[2]);
    if (seconds > 59) return 0;
    return (minutes * 60) + seconds;
  }

  function runtimeLabel(seconds) {
    const safe = clamp(Math.round(Number(seconds) || 0), 0, 5400);
    return `${String(Math.floor(safe / 60)).padStart(2, '0')}:${String(safe % 60).padStart(2, '0')}`;
  }

  function clearRemakeSourceMedia() {
    if (remakeSource?.ownedUrl) URL.revokeObjectURL(remakeSource.url);
    if (remakeSource?.ownedPoster) URL.revokeObjectURL(remakeSource.poster);
    els.remakeSourceVideo.pause();
    els.remakeSourceVideo.removeAttribute('src');
    els.remakeSourceEmbed.removeAttribute('src');
    els.remakeSourcePoster.removeAttribute('src');
  }

  function resetRemakePlan() {
    remakePlan = null;
    els.remakeTimeline.hidden = true;
    els.remakeTimeline.innerHTML = '';
    els.remakeTimelineEmpty.hidden = false;
    els.remakeSegmentCount.textContent = '0 SEGMENTS';
    els.exportRemakePlan.disabled = true;
    els.renderFullRemake.disabled = true;
    els.remakeEngineNote.className = 'remake-engine-note';
    els.remakeEngineNote.textContent = 'Sequence planning works in this browser. Final character replacement requires a connected video-generation engine.';
  }

  function showRemakeSource() {
    const source = remakeSource;
    [els.remakeSourcePoster, els.remakeSourceVideo, els.remakeSourceEmbed].forEach(node => { node.hidden = true; });
    els.remakeSourcePlaceholder.hidden = !!source && source.kind !== 'page';
    if (!source) {
      els.remakeSourceType.textContent = 'SOURCE / WAITING';
      els.remakeSourceRuntime.textContent = '--:--';
      els.remakeSourceName.textContent = 'No source';
      return;
    }
    if (source.kind === 'youtube' || source.kind === 'vimeo') {
      els.remakeSourceEmbed.src = source.embed;
      els.remakeSourceEmbed.hidden = false;
    } else if (source.kind === 'video' || source.kind === 'file') {
      els.remakeSourceVideo.src = source.url;
      els.remakeSourceVideo.hidden = false;
    } else if (source.poster) {
      els.remakeSourcePoster.src = source.poster;
      els.remakeSourcePoster.hidden = false;
    } else {
      els.remakeSourcePlaceholder.hidden = false;
      $('strong', els.remakeSourcePlaceholder).textContent = 'AD PAGE LINKED';
      $('small', els.remakeSourcePlaceholder).textContent = 'The render engine will resolve the source media';
    }
    els.remakeSourceType.textContent = `SOURCE / ${source.platform}`;
    els.remakeSourceRuntime.textContent = runtimeLabel(source.duration || parseRemakeRuntime());
    els.remakeSourceName.textContent = source.name;
  }

  function showRemakeCharacter() {
    const character = remakeCharacter;
    els.remakeCharacterPreview.innerHTML = character ? `<img alt="Character reference" src="${character.url}">` : '<svg><use href="#i-image"/></svg>';
    els.remakeCharacterName.textContent = character ? character.name : 'Add character reference';
    els.remakeCharacterOverlay.hidden = !character;
    els.remakeWipe.hidden = !character || !remakeSource;
    if (character) els.remakeCharacterOverlay.src = character.url;
    else els.remakeCharacterOverlay.removeAttribute('src');
  }

  function renderRemakeOptions() {
    if (!els.remakePresentationGroup.children.length) {
      const labels = { keep:'Keep', feminine:'Feminine', masculine:'Masculine', neutral:'Neutral' };
      els.remakePresentationGroup.innerHTML = Object.entries(labels).map(([value,label]) => `<button data-remake-presentation="${value}" aria-pressed="false">${label}</button>`).join('');
      $$('[data-remake-presentation]', els.remakePresentationGroup).forEach(button => button.addEventListener('click', () => {
        state.remakePresentation = button.dataset.remakePresentation;
        renderRemakeOptions(); resetRemakePlan(); persist(); updateRemakeReadiness();
      }));
    }
    $$('[data-remake-presentation]', els.remakePresentationGroup).forEach(button => setButtonState(button, button.dataset.remakePresentation === state.remakePresentation));
    const ruleState = { motion:state.remakeKeepMotion, cuts:state.remakeKeepCuts, audio:state.remakeKeepAudio, setting:state.remakeKeepSetting };
    $$('[data-remake-rule]').forEach(button => setButtonState(button, !!ruleState[button.dataset.remakeRule]));
    els.remakeContinuity.value = String(state.remakeContinuity);
    els.remakeContinuityValue.textContent = String(state.remakeContinuity);
    els.remakeDuration.value = state.remakeDuration;
    els.remakeTransition.value = state.remakeTransition;
  }

  function updateRemakeSummary() {
    const fields = $$('strong', els.remakeSummary);
    fields[0].textContent = remakeSource ? remakeSource.platform : 'Waiting';
    fields[1].textContent = remakeCharacter ? state.remakePresentation : 'Waiting';
    fields[2].textContent = `${state.resolution.toUpperCase()} · SOURCE ASPECT`;
  }

  function updateRemakeReadiness() {
    const ready = !!remakeSource && !!remakeCharacter;
    els.buildRemakePlan.disabled = !ready;
    els.previewRemakeTransition.disabled = !ready;
    els.remakeBlend.disabled = !ready;
    els.useStudioCast.disabled = personMedia.length === 0;
    els.remakeStatus.textContent = remakePlan ? 'PLANNED' : (ready ? 'READY' : 'SETUP');
    els.remakeStatus.className = `page-stat remake-state ${remakePlan ? 'planned' : (ready ? 'ready' : '')}`.trim();
    updateRemakeSummary();
  }

  function renderRemakeWorkspace() {
    if (els.remakeUrl.value !== state.remakeUrl) els.remakeUrl.value = state.remakeUrl;
    renderRemakeOptions();
    showRemakeSource();
    showRemakeCharacter();
    updateRemakeBlend();
    updateRemakeReadiness();
  }

  function updateRemakeBlend() {
    const value = Number(els.remakeBlend.value || 0);
    els.remakeMonitor.style.setProperty('--remake-blend', `${value}%`);
    els.remakeBlendReadout.textContent = value <= 0 ? 'SOURCE 100%' : (value >= 100 ? 'RECAST 100%' : `RECAST ${value}%`);
  }

  async function loadRemakeUrl() {
    let raw = els.remakeUrl.value.trim();
    if (!raw) { toast('Paste a YouTube, ad, or video link first.', 'error'); return; }
    if (!/^https?:\/\//i.test(raw)) raw = `https://${raw}`;
    let url;
    try { url = new URL(raw); } catch (_) { toast('That does not look like a complete video link.', 'error'); return; }
    if (!['http:', 'https:'].includes(url.protocol)) { toast('Use an http or https video link.', 'error'); return; }
    const validHostname = /^(?:[a-z0-9-]+\.)+[a-z]{2,}$/i.test(url.hostname) || /^\d{1,3}(?:\.\d{1,3}){3}$/.test(url.hostname);
    if (!validHostname) { toast('Enter a complete public video or campaign URL.', 'error'); return; }
    clearRemakeSourceMedia();
    const youtubeId = youtubeIdFromUrl(url);
    const vimeoMatch = url.hostname.includes('vimeo.com') ? url.pathname.match(/\/(\d{6,12})(?:$|\/)/) : null;
    const directVideo = /\.(mp4|webm|mov|m4v)(?:$|[?#])/i.test(url.href);
    if (youtubeId) {
      remakeSource = { kind:'youtube', platform:'YOUTUBE', name:`YouTube · ${youtubeId}`, url:url.href, embed:`https://www.youtube-nocookie.com/embed/${encodeURIComponent(youtubeId)}?rel=0`, poster:`https://i.ytimg.com/vi/${encodeURIComponent(youtubeId)}/hqdefault.jpg`, duration:parseRemakeRuntime() };
    } else if (vimeoMatch) {
      remakeSource = { kind:'vimeo', platform:'VIMEO', name:`Vimeo · ${vimeoMatch[1]}`, url:url.href, embed:`https://player.vimeo.com/video/${vimeoMatch[1]}?dnt=1`, duration:parseRemakeRuntime() };
    } else if (directVideo) {
      remakeSource = { kind:'video', platform:'DIRECT VIDEO', name:decodeURIComponent(url.pathname.split('/').pop() || url.hostname), url:url.href, duration:parseRemakeRuntime() };
    } else {
      remakeSource = { kind:'page', platform:'AD / WEB', name:url.hostname.replace(/^www\./, ''), url:url.href, duration:parseRemakeRuntime() };
    }
    state.remakeUrl = url.href;
    resetRemakePlan(); renderRemakeWorkspace(); persist();
    toast(`${remakeSource.platform.toLowerCase()} source linked.`, 'ok');
  }

  async function handleRemakeVideo(file) {
    if (!file || file.size === 0 || !(file.type.startsWith('video/') || /\.(mp4|webm|mov|m4v)$/i.test(file.name || ''))) { toast('Choose an MP4, WebM, MOV, or M4V video.', 'error'); return; }
    if (file.size > 500 * 1024 * 1024) { toast('Keep the source under 500 MB for browser planning.', 'error'); return; }
    let meta;
    try { meta = await inspectVideo(file); } catch (_) { toast('That video could not be read.', 'error'); return; }
    if (meta.duration > 900.1) { toast('FrameShift currently maps sources up to 15 minutes.', 'error'); return; }
    const frames = await extractVideoFrames(file, [.03], 960).catch(() => []);
    clearRemakeSourceMedia();
    const duration = Math.ceil(meta.duration);
    remakeSource = { kind:'file', platform:'LOCAL VIDEO', name:file.name, url:URL.createObjectURL(file), ownedUrl:true, poster:frames[0] ? URL.createObjectURL(frames[0]) : '', ownedPoster:!!frames[0], duration };
    state.remakeUrl = '';
    state.remakeDuration = runtimeLabel(duration);
    resetRemakePlan(); renderRemakeWorkspace(); persist();
    toast('The full source video is ready to map.', 'ok');
  }

  function setRemakeCharacter(item) {
    if (remakeCharacter?.ownedUrl) URL.revokeObjectURL(remakeCharacter.url);
    remakeCharacter = item;
    resetRemakePlan(); showRemakeCharacter(); updateRemakeReadiness();
    els.remakeBlend.value = '0'; updateRemakeBlend();
  }

  async function handleRemakeCharacter(file) {
    if (!file || file.size === 0) { toast('Choose a character photo or short reference clip.', 'error'); return; }
    if (/^image\/(jpeg|png|webp)$/i.test(file.type)) {
      try { await inspectImageFile(file); } catch (_) { toast('That character image could not be read.', 'error'); return; }
      setRemakeCharacter({ name:file.name, url:URL.createObjectURL(file), ownedUrl:true, source:'remake' });
      toast('Character reference added.', 'ok'); return;
    }
    if (file.type.startsWith('video/') || /\.(mp4|webm|mov|m4v)$/i.test(file.name || '')) {
      if (file.size > 250 * 1024 * 1024) { toast('Keep the character clip under 250 MB.', 'error'); return; }
      try {
        const frames = await extractVideoFrames(file, [.18], 720);
        if (!frames[0]) throw new Error('no frame');
        setRemakeCharacter({ name:`${file.name} · reference frame`, url:URL.createObjectURL(frames[0]), ownedUrl:true, source:'remake' });
        toast('A character reference was lifted from the clip.', 'ok');
      } catch (_) { toast('That character clip could not be read.', 'error'); }
      return;
    }
    toast('Use a JPG, PNG, WebP, or video reference.', 'error');
  }

  function useCurrentStudioCast() {
    if (!personMedia[0]) { toast('Add a cast reference in Studio first.', 'error'); return; }
    setRemakeCharacter({ name:personMedia[0].name || 'Studio cast', url:personMedia[0].url, ownedUrl:false, source:'studio', ref:personMedia[0] });
    toast('Current Studio cast loaded.', 'ok');
  }

  function previewRemakeTransition() {
    if (!remakeSource || !remakeCharacter) return;
    cancelAnimationFrame(remakeTransitionFrame);
    const reverse = Number(els.remakeBlend.value) > 50;
    const from = reverse ? 100 : 0;
    const to = reverse ? 0 : 100;
    const started = performance.now();
    const animate = now => {
      const progress = clamp((now - started) / 1500, 0, 1);
      const eased = .5 - Math.cos(progress * Math.PI) / 2;
      els.remakeBlend.value = String(Math.round(from + ((to - from) * eased)));
      updateRemakeBlend();
      if (progress < 1) remakeTransitionFrame = requestAnimationFrame(animate);
    };
    remakeTransitionFrame = requestAnimationFrame(animate);
  }

  function buildFullRemakePlan() {
    if (!remakeSource || !remakeCharacter) return;
    const duration = parseRemakeRuntime();
    if (!duration || duration > 900) {
      resetRemakePlan(); updateRemakeReadiness();
      toast('Enter a source runtime from 00:01 to 15:00.', 'error'); els.remakeDuration.focus(); return;
    }
    state.remakeDuration = runtimeLabel(duration);
    const count = Math.ceil(duration / 15);
    const segments = Array.from({ length:count }, (_, index) => {
      const start = index * 15;
      const end = Math.min(duration, start + 15);
      const phase = index === 0 ? 'Acquire identity' : (index === count - 1 ? 'Finish + QC' : 'Continuity pass');
      return { index:index + 1, start, end, phase, status:'planned' };
    });
    const rules = {
      performance:state.remakeKeepMotion, editAndCamera:state.remakeKeepCuts,
      originalSound:state.remakeKeepAudio, sceneContinuity:state.remakeKeepSetting
    };
    remakePlan = {
      version:1, createdAt:new Date().toISOString(), source:{ type:remakeSource.platform, name:remakeSource.name, url:remakeSource.ownedUrl ? null : remakeSource.url, duration },
      character:{ name:remakeCharacter.name, presentation:state.remakePresentation }, transition:state.remakeTransition,
      continuity:state.remakeContinuity, rules, delivery:{ resolution:state.resolution, aspect:'source', audio:state.remakeKeepAudio ? 'preserve' : 'replace' }, segments
    };
    els.remakeTimeline.innerHTML = segments.map(segment => `<article class="remake-segment"><span>${runtimeLabel(segment.start)}—${runtimeLabel(segment.end)}</span><i></i><small>${segment.phase}</small></article>`).join('');
    els.remakeTimeline.hidden = false;
    els.remakeTimelineEmpty.hidden = true;
    els.remakeSegmentCount.textContent = `${count} ${count === 1 ? 'SEGMENT' : 'SEGMENTS'}`;
    els.exportRemakePlan.disabled = false;
    els.renderFullRemake.disabled = false;
    els.remakeEngineNote.className = 'remake-engine-note ok';
    els.remakeEngineNote.textContent = `${count} continuity-locked passes mapped across ${runtimeLabel(duration)}. The plan is ready for a connected render engine.`;
    updateRemakeReadiness(); persist();
    toast(`Whole-video sequence built in ${count} passes.`, 'ok');
  }

  function exportFullRemakePlan() {
    if (!remakePlan) return;
    const blob = new Blob([JSON.stringify(remakePlan, null, 2)], { type:'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `frameshift-remake-plan-${Date.now()}.json`; document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast('Remake plan exported.', 'ok');
  }

  function requestFullRemakeRender() {
    if (!remakePlan) return;
    els.remakeStatus.textContent = 'ENGINE OFFLINE';
    els.remakeStatus.className = 'page-stat remake-state error';
    els.remakeEngineNote.className = 'remake-engine-note error';
    els.remakeEngineNote.textContent = 'The complete sequence is planned, but no video-generation engine is connected. Export the plan or connect a rendering backend to produce the replacement video.';
    toast('The remake plan is ready. Connect a video engine to render it.', 'error');
  }

  function playStage() { if (!els.stageVideo.hidden) els.stageVideo.paused ? els.stageVideo.play().catch(() => {}) : els.stageVideo.pause(); }

  function setCompare(active) {
    const canCompare = !!stageTakeId && !els.holdImage.hidden;
    const enabled = !!active && canCompare;
    els.stage.classList.toggle('comparing', enabled);
    els.stage.classList.remove('holding');
    els.compareRange.hidden = !enabled;
    els.compareHandle.hidden = !enabled;
    const button = $('[data-stage-action="compare"]', els.stageActions);
    if (button) button.textContent = enabled ? 'Close compare' : 'Compare';
  }

  function bindDropZone(element, handler) {
    ['dragenter','dragover'].forEach(type => element.addEventListener(type, event => { event.preventDefault(); element.classList.add('dragging'); }));
    ['dragleave','drop'].forEach(type => element.addEventListener(type, event => { event.preventDefault(); element.classList.remove('dragging'); }));
    element.addEventListener('drop', event => { const file = event.dataTransfer?.files?.[0]; if (file) handler(file); });
  }

  function bindEvents() {
    $$('.nav-item').forEach(button => button.addEventListener('click', () => navigate(button.dataset.section)));
    $$('[data-go-studio]').forEach(button => button.addEventListener('click', () => navigate('studio')));
    els.menuTrigger.addEventListener('click', () => els.sideNav.classList.contains('open') ? closeDrawer() : openDrawer());
    els.scrim.addEventListener('click', closeDrawer);
    document.addEventListener('keydown', event => { if (event.key === 'Escape') closeDrawer(); });
    $$('.mode-switcher button').forEach(button => button.addEventListener('click', () => { state.mode = button.dataset.mode; renderMode(); persist(); }));
    els.dismissHint.addEventListener('click', () => { state.hintDismissed = true; els.firstHint.hidden = true; persist(); });
    els.motionPrompt.addEventListener('input', () => { state.prompt = els.motionPrompt.value; renderComposer(); persist(); });
    els.savePrompt.addEventListener('click', savePromptRecipe);
    els.openPromptHistory.addEventListener('click', openPromptHistory);
    els.closePromptHistory.addEventListener('click', closePromptHistory);
    els.promptHistoryDialog.addEventListener('click', event => { if (event.target === els.promptHistoryDialog) closePromptHistory(); });
    els.generateButton.addEventListener('click', submitGeneration);
    els.performanceUpload.addEventListener('click', () => els.performanceInput.click()); els.performanceInput.addEventListener('change', () => { handlePerformanceFile(els.performanceInput.files[0]); els.performanceInput.value = ''; });
    els.personUpload.addEventListener('click', () => els.personInput.click()); els.personInput.addEventListener('change', () => { handlePersonFile(els.personInput.files[0]); els.personInput.value = ''; });
    els.startUpload.addEventListener('click', () => els.startInput.click()); els.startInput.addEventListener('change', () => { handleImageFile(els.startInput.files[0], 'start'); els.startInput.value = ''; });
    els.endUpload.addEventListener('click', () => els.endInput.click()); els.endInput.addEventListener('change', () => { handleImageFile(els.endInput.files[0], 'end'); els.endInput.value = ''; });
    els.draftStill.addEventListener('click', () => toast('Connect an image model to draft a still, then try again.', 'error'));
    els.copyUpload.addEventListener('click', () => els.copyInput.click()); els.copyInput.addEventListener('change', () => { handleCopyVideo(els.copyInput.files[0]); els.copyInput.value = ''; });
    bindDropZone(els.performanceUpload, handlePerformanceFile);
    bindDropZone(els.personUpload, handlePersonFile);
    bindDropZone(els.startUpload, file => handleImageFile(file, 'start'));
    bindDropZone(els.endUpload, file => handleImageFile(file, 'end'));
    bindDropZone(els.copyUpload, handleCopyVideo);
    els.lockSubject.addEventListener('click', () => { state.lockSubject = !state.lockSubject; setButtonState(els.lockSubject, state.lockSubject); persist(); });
    els.lockSetting.addEventListener('click', () => { state.lockSetting = !state.lockSetting; setButtonState(els.lockSetting, state.lockSetting); persist(); });
    els.protectBackground.addEventListener('click', () => { state.protectBackground = !state.protectBackground; renderAdvanced(); persist(); });
    els.randomizeSeed.addEventListener('click', () => { state.seed = Math.floor(Math.random() * 999999999) + 1; renderAdvanced(); persist(); });
    els.seedInput.addEventListener('input', () => { const value = Math.round(Number(els.seedInput.value)); if (Number.isFinite(value) && value > 0) { state.seed = clamp(value, 1, 999999999); persist(); } });
    els.seedInput.addEventListener('change', () => { state.seed = clamp(Math.round(Number(els.seedInput.value)) || defaults.seed, 1, 999999999); renderAdvanced(); persist(); });
    [
      [els.identityFidelity,'identityFidelity'], [els.lightingFidelity,'lightingFidelity'], [els.motionFidelity,'motionFidelity'], [els.edgeFidelity,'edgeFidelity'], [els.temporalFidelity,'temporalFidelity'],
      [els.lipSync,'lipSync'], [els.originalMix,'originalMix'], [els.voiceMix,'voiceMix'], [els.ambientMix,'ambientMix']
    ].forEach(([input,key]) => input.addEventListener('input', () => { state[key] = Number(input.value); renderAdvanced(); persist(); }));
    els.spokenLine.addEventListener('input', () => { state.spokenLine = els.spokenLine.value; if (state.spokenLine.trim()) state.sound = true; renderVoice(); persist(); });
    $$('[data-delivery]', els.deliveryTags).forEach(button => button.addEventListener('click', () => applyDeliveryTag(button.dataset.delivery)));
    els.auditionVoice.addEventListener('click', auditionSpokenLine);
    els.soundToggle.addEventListener('click', () => { if (els.soundToggle.disabled) return; state.sound = !state.sound; renderVoice(); persist(); });
    els.recordVoice.addEventListener('click', startVoiceRecording); els.voiceUpload.addEventListener('click', () => els.voiceInput.click()); els.voiceInput.addEventListener('change', () => { handleVoiceFile(els.voiceInput.files[0]); els.voiceInput.value = ''; }); els.clearVoice.addEventListener('click', clearVoice);
    els.closeApps.addEventListener('click', closeApps); els.appSheet.addEventListener('click', event => { if (event.target === els.appSheet) closeApps(); });
    els.installWeb.addEventListener('click', async () => { if (deferredInstall) { deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; els.installCopy.textContent = 'Installed or dismissed'; } else toast('Use your browser menu and choose Install app or Add to Home Screen.'); });
    els.notificationOption.addEventListener('click', toggleNotifications);
    els.remakeUrl.addEventListener('input', () => { state.remakeUrl = els.remakeUrl.value.slice(0, 1200); persist(); });
    els.remakeUrl.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); loadRemakeUrl(); } });
    els.analyzeRemakeUrl.addEventListener('click', loadRemakeUrl);
    els.remakeVideoInput.addEventListener('change', () => { handleRemakeVideo(els.remakeVideoInput.files[0]); els.remakeVideoInput.value = ''; });
    els.remakeCharacterInput.addEventListener('change', () => { handleRemakeCharacter(els.remakeCharacterInput.files[0]); els.remakeCharacterInput.value = ''; });
    [[els.remakeVideoUpload, els.remakeVideoInput], [els.remakeCharacterUpload, els.remakeCharacterInput]].forEach(([trigger, input]) => {
      trigger.addEventListener('keydown', event => {
        if (event.key !== 'Enter' && event.key !== ' ') return;
        event.preventDefault(); input.click();
      });
    });
    els.useStudioCast.addEventListener('click', useCurrentStudioCast);
    bindDropZone(els.remakeVideoUpload, handleRemakeVideo);
    bindDropZone(els.remakeCharacterUpload, handleRemakeCharacter);
    $$('[data-remake-rule]').forEach(button => button.addEventListener('click', () => {
      const keys = { motion:'remakeKeepMotion', cuts:'remakeKeepCuts', audio:'remakeKeepAudio', setting:'remakeKeepSetting' };
      const key = keys[button.dataset.remakeRule];
      state[key] = !state[key]; renderRemakeOptions(); resetRemakePlan(); updateRemakeReadiness(); persist();
    }));
    els.remakeContinuity.addEventListener('input', () => { state.remakeContinuity = Number(els.remakeContinuity.value); els.remakeContinuityValue.textContent = String(state.remakeContinuity); resetRemakePlan(); updateRemakeReadiness(); persist(); });
    els.remakeDuration.addEventListener('input', () => { resetRemakePlan(); updateRemakeReadiness(); });
    els.remakeDuration.addEventListener('change', () => { const seconds = parseRemakeRuntime(); if (seconds && seconds <= 900) state.remakeDuration = runtimeLabel(seconds); else { toast('Use MM:SS, up to 15:00.', 'error'); state.remakeDuration = defaults.remakeDuration; } renderRemakeOptions(); resetRemakePlan(); updateRemakeReadiness(); persist(); });
    els.remakeTransition.addEventListener('change', () => { state.remakeTransition = els.remakeTransition.value; resetRemakePlan(); updateRemakeReadiness(); persist(); });
    els.remakeBlend.addEventListener('input', updateRemakeBlend);
    els.previewRemakeTransition.addEventListener('click', previewRemakeTransition);
    els.buildRemakePlan.addEventListener('click', buildFullRemakePlan);
    els.exportRemakePlan.addEventListener('click', exportFullRemakePlan);
    els.renderFullRemake.addEventListener('click', requestFullRemakeRender);
    $$('[data-library-filter]').forEach(button => button.addEventListener('click', () => { libraryFilter = button.dataset.libraryFilter; renderLibrary(); }));
    els.librarySearch.addEventListener('input', () => { libraryQuery = els.librarySearch.value; renderLibrary(); });
    els.relinkInput.addEventListener('change', () => { handleRelink(els.relinkInput.files[0]); els.relinkInput.value = ''; });
    els.stageActions.addEventListener('click', event => {
      const button = event.target.closest('[data-stage-action]'); if (!button) return;
      const take = state.library.find(t => t.id === stageTakeId);
      if (button.dataset.stageAction === 'play') playStage();
      if (button.dataset.stageAction === 'pieces' && take) playPieces(take);
      if (button.dataset.stageAction === 'download' && take) downloadTake(take);
      if (button.dataset.stageAction === 'another') { stageTakeId = null; renderStage(); renderFilmstrip(); }
      if (button.dataset.stageAction === 'extend') toast('Connect a video model before adding the next 15 seconds.', 'error');
      if (button.dataset.stageAction === 'compare') setCompare(!els.stage.classList.contains('comparing'));
    });
    const holdButton = $('[data-stage-action="hold"]', els.stageActions);
    holdButton.addEventListener('pointerdown', () => els.stage.classList.add('holding'));
    holdButton.addEventListener('pointerup', () => els.stage.classList.remove('holding'));
    holdButton.addEventListener('pointerleave', () => els.stage.classList.remove('holding'));
    holdButton.addEventListener('keydown', event => { if (event.key === ' ' || event.key === 'Enter') els.stage.classList.add('holding'); });
    holdButton.addEventListener('keyup', event => { if (event.key === ' ' || event.key === 'Enter') els.stage.classList.remove('holding'); });
    const hold = active => els.stage.classList.toggle('holding', active);
    els.stage.addEventListener('pointerdown', event => { if (event.button === 0 && stageTakeId && !els.stage.classList.contains('comparing')) hold(true); });
    window.addEventListener('pointerup', () => hold(false));
    els.compareRange.addEventListener('input', () => els.stage.style.setProperty('--compare-position', `${els.compareRange.value}%`));
    window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); deferredInstall = event; els.installCopy.textContent = 'Ready to install'; });
    els.stageVideo.addEventListener('timeupdate', () => {
      const seconds = Math.max(0, els.stageVideo.currentTime || 0); const frames = Math.floor((seconds % 1) * 24);
      const total = Math.floor(seconds); const s = total % 60; const m = Math.floor(total / 60) % 60; const h = Math.floor(total / 3600);
      els.stageTimecode.textContent = [h,m,s,frames].map(value => String(value).padStart(2,'0')).join(':');
    });
    window.addEventListener('resize', syncDrawerA11y);
    window.addEventListener('beforeunload', () => {
      persist(true); previewStream?.getTracks().forEach(track => track.stop()); window.speechSynthesis?.cancel?.();
      cancelAnimationFrame(remakeTransitionFrame);
      liveUrls.forEach(url => URL.revokeObjectURL(url));
      [startFrame,endFrame,...personMedia].forEach(item => item?.ownedUrl && URL.revokeObjectURL(item.url));
      if (customPerformance?.ownedUrl) URL.revokeObjectURL(customPerformance.url);
      if (remakeSource?.ownedUrl) URL.revokeObjectURL(remakeSource.url);
      if (remakeSource?.ownedPoster) URL.revokeObjectURL(remakeSource.poster);
      if (remakeCharacter?.ownedUrl) URL.revokeObjectURL(remakeCharacter.url);
    });
  }

  function openDb() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('frameshift-media', 1);
      request.onupgradeneeded = () => request.result.createObjectStore('media');
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
    });
  }
  async function idbPut(key, blob) { const db = await openDb(); return new Promise((resolve, reject) => { const tx = db.transaction('media', 'readwrite'); tx.objectStore('media').put(blob, key); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); }
  async function idbGet(key) { const db = await openDb(); return new Promise((resolve, reject) => { const req = db.transaction('media').objectStore('media').get(key); req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); }); }
  async function idbDelete(key) { const db = await openDb(); return new Promise((resolve, reject) => { const tx = db.transaction('media', 'readwrite'); tx.objectStore('media').delete(key); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); }
  async function resolveTakeUrl(take) {
    if (liveUrls.has(take.id)) return liveUrls.get(take.id);
    if (!take.mediaKey) return null;
    const blob = await idbGet(take.mediaKey).catch(() => null);
    if (!blob) return null;
    const url = URL.createObjectURL(blob); liveUrls.set(take.id, url); return url;
  }

  function init() {
    renderPerformances(); renderCustomPerformance(); renderOptions(); renderAdvanced(); renderPeople(); renderStartFrame(); renderCopiedFile(); renderVoice(); renderMode(); renderStatus(); renderFilmstrip(); renderNotificationState(); renderRemakeWorkspace(); bindEvents(); syncDrawerA11y();
    if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('./sw.js').catch(() => {});
  }

  init();
})();
