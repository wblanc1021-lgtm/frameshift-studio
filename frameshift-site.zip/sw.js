const CACHE = 'frameshift-v13';
const ASSETS = [
  './', './index.html', './styles.css?v=13', './app.js?v=13', './manifest.webmanifest',
  './assets/app/frameshift-favicon-32.png', './assets/app/frameshift-icon-64.png', './assets/app/frameshift-icon-180.png', './assets/app/frameshift-icon-192.png', './assets/app/frameshift-icon-512.png', './assets/app/frameshift-icon-maskable-512.png', './assets/cover/frameshift-wave-cover.jpg',
  './assets/performance/black-coat.jpg', './assets/performance/red-coat.jpg', './assets/performance/ivory-suit.jpg', './assets/performance/cobalt-glass.jpg'
];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)).then(() => self.skipWaiting())));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())));
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== location.origin) return;
  if (event.request.mode === 'navigate') {
    event.respondWith(fetch(event.request).then(response => { const clone = response.clone(); caches.open(CACHE).then(cache => cache.put('./', clone)); return response; }).catch(() => caches.match('./')));
    return;
  }
  event.respondWith(caches.match(event.request).then(cached => {
    const network = fetch(event.request).then(response => { if (response.ok) { const clone = response.clone(); caches.open(CACHE).then(cache => cache.put(event.request, clone)); } return response; }).catch(() => cached);
    return cached || network;
  }));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(clients.matchAll({ type:'window', includeUncontrolled:true }).then(openClients => {
    const current = openClients.find(client => client.url.startsWith(self.location.origin));
    return current ? current.focus() : clients.openWindow('./');
  }));
});
