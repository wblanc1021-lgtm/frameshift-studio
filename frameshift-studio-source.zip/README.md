# FrameShift

FrameShift is a dark, instrument-like single-page studio for animating a still, recasting a performer, marking a local video in 15-second pieces, and planning a full-video character remake from a YouTube, campaign, direct-video, or local-file source. The recast workflow supports any cast presentation, and its direction field offers contextual prompt suggestions while the user writes.

The production-ready static site lives in `dist/` and has no build step. Open `dist/index.html` through a local web server to use file handling, IndexedDB media persistence, installability, audio recording, source-to-character transition preview, automatic 15-second sequence mapping, and JSON remake-plan export. The project includes an original app cover, PWA icons, four art-directed performance stills, and an offline asset shell. Hosted video and image generation are intentionally represented by honest connection errors until a model backend is attached.
